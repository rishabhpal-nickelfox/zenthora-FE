import { ElementRef, Renderer2 } from '@angular/core';
import { DefaultValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class TrimValueAccessorDirective extends DefaultValueAccessor {
    constructor(renderer: Renderer2, elementRef: ElementRef, compositionMode: boolean | null);
    onTrimInput(value: string): void;
    onTrimBlur(value: string): void;
    writeValue(value: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrimValueAccessorDirective, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TrimValueAccessorDirective, "    input:not([type=checkbox]):not([type=radio]):not([type=password]):not([readonly]):not(.ng-trim-ignore)[formControlName],    input:not([type=checkbox]):not([type=radio]):not([type=password]):not([readonly]):not(.ng-trim-ignore)[formControl],    input:not([type=checkbox]):not([type=radio]):not([type=password]):not([readonly]):not(.ng-trim-ignore)[ngModel],    textarea:not([readonly]):not(.ng-trim-ignore)[formControlName],    textarea:not([readonly]):not(.ng-trim-ignore)[formControl],    textarea:not([readonly]):not(.ng-trim-ignore)[ngModel],    :not([readonly]):not(.ng-trim-ignore)[ngDefaultControl]  ", never, {}, {}, never, never, false, never>;
}
export declare class TrimValueAccessorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TrimValueAccessorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TrimValueAccessorModule, [typeof TrimValueAccessorDirective], never, [typeof TrimValueAccessorDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TrimValueAccessorModule>;
}
