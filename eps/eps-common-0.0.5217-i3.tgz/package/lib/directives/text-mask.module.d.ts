import { ElementRef, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export interface TextMaskConfig {
    mask: Array<string | RegExp> | ((raw: string) => Array<string | RegExp>) | false;
    guide?: boolean;
    placeholderChar?: string;
    pipe?: (conformedValue: string, config: TextMaskConfig) => false | string | object;
    keepCharPositions?: boolean;
    showMask?: boolean;
}
export declare class MaskedInputDirective implements ControlValueAccessor, OnChanges {
    private renderer;
    private elementRef;
    private compositionMode;
    textMaskConfig: TextMaskConfig;
    private textMaskInputElement;
    private inputElement;
    private composing;
    private onChange;
    private onTouched;
    constructor(renderer: Renderer2, elementRef: ElementRef, compositionMode: boolean | null);
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    handleInput(value: any): void;
    handleBlur(): void;
    compositionStart(): void;
    compositionEnd(value: any): void;
    private setupMask;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaskedInputDirective, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MaskedInputDirective, "[textMask]", ["textMask"], { "textMaskConfig": { "alias": "textMask"; "required": false; }; }, {}, never, never, false, never>;
}
export declare class TextMaskModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextMaskModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextMaskModule, [typeof MaskedInputDirective], never, [typeof MaskedInputDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextMaskModule>;
}
