export declare class ObjectHelper {
    static mapToObject(map: Map<string, any>): any;
    static isDefined(smth: any): boolean;
    static isNumber(smth: any): boolean;
    static deepGet(obj: any, path: any): any;
    static isEmptyObject(obj: any): boolean;
    static deepEqual(obj1: any, obj2: any): any;
    static cloneDeep(obj1: any): any;
    static mergeProperties(target: any, source: any): Object;
}
export declare function isDefined(smth: any): boolean;
export declare function isNumber(smth: any): boolean;
export declare function deepGet(obj: any, path: any): any;
export declare function isEmptyObject(obj: any): boolean;
export declare function objectPropertiesAreEqual(obj1: any, obj2: any): boolean;
export declare function deepEqual(obj1: any, obj2: any): any;
export declare function isJSON(str: string): boolean;
