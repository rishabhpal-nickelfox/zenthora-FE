export declare class ContactHelper {
    static formatPhone(input: string): string;
}
