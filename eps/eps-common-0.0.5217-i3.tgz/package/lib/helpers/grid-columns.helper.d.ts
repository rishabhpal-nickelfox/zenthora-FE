import { GridAreaModel } from '../models/sale/template/invoice-template.model';
export declare class GridColumnsHelper {
    static readonly GRID_UNITS = 96;
    static readonly MIN_LABEL_COLUMN = 2;
    static readonly MIN_AMOUNT_COLUMN = 3;
    static getWeightedColumns(layout: GridAreaModel[], minWidth: string): string;
    static normalizeTotalsSplit(columnCount: number, labelColumnSpan?: number, amountColumnSpan?: number): {
        labelStart: number;
        amountStart: number;
    };
    static getTotalsSplitUnits(layout: GridAreaModel[], labelColumnSpan?: number, amountColumnSpan?: number): {
        memo: number;
        label: number;
        amount: number;
    };
    static getWeightedTotalsColumns(layout: GridAreaModel[], minWidth: string, labelColumnSpan?: number, amountColumnSpan?: number): string;
    static getWeightedMemoTotalsColumns(layout: GridAreaModel[], minWidth: string, labelColumnSpan?: number, amountColumnSpan?: number): string;
    static getAutoMemoTotalsColumns(beforeLastWidth: string, lastWidth: string): string;
    static getAutoColumns(columnCount: number, beforeLastWidth: string, lastWidth: string): string;
    static getAutoTotalsColumns(beforeLastWidth: string, lastWidth: string): string;
    static toUnits(widths: number[], totalUnits: number, minUnits: number): number[];
    static applyUnits(layout: GridAreaModel[], units: number[]): void;
    static fitToUnits(layout: GridAreaModel[], totalUnits: number, minUnits: number): void;
    static reorder<T extends GridAreaModel>(layout: T[], from: number, to: number): boolean;
    static applyOrder(layout: GridAreaModel[]): void;
    static sortByX(layout: GridAreaModel[]): GridAreaModel[];
    static getColumnOrder(layout: GridAreaModel[], colId: any): number;
    static hasColumn(layout: GridAreaModel[], colId: any): boolean;
    private static weightedTrack;
    private static sumUnits;
    private static shrinkable;
    private static fraction;
}
