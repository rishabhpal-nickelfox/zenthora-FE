import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';
export declare class FormHelper {
    private static getFormControls;
    static getAllFormControls(group: FormGroup, exceptionKeys?: string[]): FormControl[];
    static getEnabledFormControls(group: FormGroup, exceptionKeys?: string[]): FormControl[];
    static validateAllFormFields(formGroup: FormGroup): void;
    static validateField(formGroup: FormGroup, field: string): void;
    static isFieldNotValid(form: FormGroup, fieldName: string): boolean;
    static updateGroupValidation(group: FormGroup | FormArray): void;
    static isFormGroupValid(group: FormGroup): boolean;
    static findInDictionaryById(dictionary: any, id: any): any;
    static validateControl(control: AbstractControl): void;
    static validateIfNotEmpty(control: AbstractControl): void;
}
