export declare class MoneyHelper {
    static getCurrencyPrefix(code: string): string;
    static readonly NUMBER_PATTERN: RegExp;
    private static readonly MAX_FRACTION_DIGITS;
    static formatAmount(amount: string | number, opts?: {
        currency?: string;
        minimumFractionDigits?: number;
        maximumFractionDigits?: number;
        locale?: string;
    }): string;
}
