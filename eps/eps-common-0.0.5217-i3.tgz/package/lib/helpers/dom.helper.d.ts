export declare function isElementVisible(e: HTMLElement): boolean;
export declare function isElementDisabled(e: HTMLElement): boolean;
export declare function findFirstFocusableIn(element: any): HTMLElement;
export declare function findNbCardBody(element: any): HTMLElement;
export declare function findNextFocusable(element: any): any;
export declare function getScrollBehavior(): ScrollBehavior;
export declare class DOMHelper {
    static stopEvent($event: Event): void;
    static focusById(id: string): void;
    static scrollById(id: string): void;
}
