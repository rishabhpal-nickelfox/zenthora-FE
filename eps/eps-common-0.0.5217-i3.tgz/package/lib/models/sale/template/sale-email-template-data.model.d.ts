import { Moment } from "moment";
import { CreateSaleRequest, Level2, LineItem, SaleDetail } from "../request/sale-request.model";
import { InvoiceItemDetailTypeEnum } from "../../../enums/sale/invoice-item-detail-type.enum";
import { PaymentStatusEnum } from "../../../enums/sale/payment-status.enum";
import { CountryISOEnum } from "../../../enums/utils/country-iso.enum";
import { CompanyInfoRowsEnum } from "../../../enums/sale/company-info-rows.enum";
import { CustomFieldModel } from "../custom-field.model";
import { InvoiceTemplateModel } from "./invoice-template.model";
import { DocTypeEnum } from "../../../enums/sale/doc-type.enum";
export interface SaleTaxRateData {
    name: string;
    percentage: number;
    amount: number;
}
export declare class SaleEmailTemplateData {
    companyInfo: CompanyInfoTemplateData;
    logo: Logo;
    fullTemplate: InvoiceTemplateModel;
    saleShortInfo: SaleShortInfoTemplateData;
    saleAdditionalInfo: SaleAdditionalInfoTemplateData;
    saleFullInfo: SaleFullInfoTemplateData;
    billingAddress: SaleAddressTemplateData;
    shippingAddress: SaleAddressTemplateData;
    shippingInfo: SaleShippingInfoTemplateData;
    customFieldsInfo: CustomFieldsTemplateData;
    invoiceItems: ItemTemplateData[];
    customerName: string;
    customerMemo: string;
    subTotal: number;
    taxPercentage: number;
    taxAmount: number;
    discount: number;
    discountExpDate: Moment;
    discountExpDateFormatted: string;
    isDiscountExpired: boolean;
    shippingCost: number;
    appliedAmount: number;
    amountDue: number;
    total: number;
    tip: number;
    currency: string;
    customFieldsEnabled: boolean;
    advancedFieldsEnabled: boolean;
    statusStampUrl?: string;
    statusLabel?: string;
    statusCode?: string;
    deletedStampUrl?: string;
    taxRates?: SaleTaxRateData[];
    isAmountInclusive?: boolean;
    discountPercentLabel?: string;
    static fromJSON(companyInfoJson: any, createSaleRequest: CreateSaleRequest, amountDue: number, appliedAmount: number, status: PaymentStatusEnum, discountExpired: boolean, paidBeforeDiscountExpired: boolean, docType: DocTypeEnum): SaleEmailTemplateData;
}
export declare class ItemTemplateData {
    name: string;
    sku: string;
    description: string;
    quantity: string | number;
    amount: string | number;
    rate: string | number;
    tax: string;
    taxable: boolean;
    serviceDate: string;
    categoryClass: string;
    other1: string;
    other2: string;
    detailType?: InvoiceItemDetailTypeEnum;
    isChild?: boolean;
    static fromLineItems(lineItems: LineItem[], currency: string): ItemTemplateData[];
    static fromJSON(json: any, currency: string, isChild?: boolean): ItemTemplateData;
}
export declare class SaleAdditionalInfoTemplateData {
    terms: string;
    dueDate: string;
    salesRep: string;
    shipDate: string;
    shipMethod: string;
    fob: string;
    trackingNumber: string;
    poNumber: string;
    customerNumber: string;
    other: string;
    static fromJSON(saleDetail: SaleDetail, level2: Level2): SaleAdditionalInfoTemplateData;
}
export declare class SaleFullInfoTemplateData {
    docDate: string;
    docNumber: string;
    docType: DocTypeEnum;
    term: string;
    dueDate: string;
    static fromJSON(saleDetail: SaleDetail, saleRequest: CreateSaleRequest, docType: DocTypeEnum): SaleFullInfoTemplateData;
}
export declare class SaleShortInfoTemplateData {
    docDate: string;
    docNumber: string;
    docType: DocTypeEnum;
    static fromJSON(json: any, docType: DocTypeEnum): SaleShortInfoTemplateData;
}
export declare class SaleAddressTemplateData {
    firstName: string;
    lastName: string;
    companyName: string;
    address1: string;
    address2: string;
    city: string;
    country: CountryISOEnum;
    state: string;
    zip: string;
    addressText?: string;
    static fromJSON(json: any): SaleAddressTemplateData;
}
export declare class CompanyInfoTemplateData {
    displayName: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
    email: string;
    phone: string;
    website: string;
    formattedPhone: string;
    static fromJSON(json: any): CompanyInfoTemplateData;
}
export interface FullTemplate extends Template {
    titleColor: string;
    itemTable: TemplateComponent[];
}
export interface Template {
    components: TemplateComponent[];
    companyInfoRows: CompanyInfoRowsEnum[];
    colorEven: string;
    colorOdd: string;
    fontColor: string;
    fontSize: number;
}
export interface TemplateComponent {
    cols: number;
    id: string;
    rows: number;
    x: number;
    y: number;
}
export declare class Logo {
    logo: string;
    logoContentType: string;
    static fromJSON(json: any): Logo;
}
export declare class CustomFieldsTemplateData {
    customFields: CustomFieldModel[];
    static fromJSON(json: any): CustomFieldsTemplateData;
}
export declare class SaleShippingInfoTemplateData {
    shipDate: string;
    shipMethod: string;
    trackingNumber: string;
    static fromJSON(json: any): SaleShippingInfoTemplateData;
}
