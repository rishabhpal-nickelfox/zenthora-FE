import { GridsterItem } from 'angular-gridster2/lib/gridsterItem.interface';
import { InvoiceEmailPaymentTemplateLogoSizeEnum } from "../../../enums/sale/invoice-email-payment-template-logo-size.enum";
import { CompanyInfoRowsEnum } from "../../../enums/sale/company-info-rows.enum";
import { InvoiceItemsTableTotalsEnum } from "../../../enums/sale/invoice-items-table-totals.enum";
import { InvoiceEmailPaymentLineStyleEnum } from "../../../enums/sale/invoice-email-payment-line-style.enum";
export declare class InvoiceTemplateModel {
    static readonly LINE_HEIGHTS: readonly number[];
    static readonly DEFAULT_LINE_HEIGHT = 1.5;
    version: string;
    components: GridAreaModel[];
    saleFullInfoTemplate: InvoiceFullInfoTemplateModel;
    itemTableTemplate: InvoiceItemTableTemplateModel;
    itemsRowsTemplate: InvoiceItemsRowsTemplateModel;
    saleShortInfoTemplate: InvoiceShortInfoTemplateModel;
    saleAdditionalInfoTemplates: InvoiceAdditionalInfoTemplateModel[];
    customFieldsTemplates: CustomFieldsTemplateModel[];
    billToTemplate: AddressTemplateModel;
    shipToTemplate: AddressTemplateModel;
    shippingInfoTemplate: ShippingInfoTemplateModel;
    companyInfoTemplates: CompanyInfoTemplateModel[];
    lineTemplates: LineTemplateModel[];
    customerMemoTemplate: CustomerMemoTemplateModel;
    customerNameTemplates: CustomerNameTemplateModel[];
    totalsTemplate: TotalsTemplateModel;
    textTemplates: TextTemplateModel[];
    titleColor: string;
    colorEven: string;
    colorOdd: string;
    fontColor: string;
    borderColor: string;
    fontSize: number;
    logoSize: InvoiceEmailPaymentTemplateLogoSizeEnum;
    minimizeVerticalSize: boolean;
    gridGap: number;
    lineHeight: number;
    /** Layout algorithm switch. true = legacy QBO render (discrete 45pt fixed columns);
     * false/undefined = the flexible auto-flow layout.
     * Set false by the editor on save so a template migrates to the new look only after its appearance is approved. **/
    legacyLayout: boolean;
    static generateGridAreaId(prefix: string): string;
    private static migrateTemplates;
    static fromJSON(templateAsString: string, defaultTemplateAsString: string): InvoiceTemplateModel;
    static toMap(instance: InvoiceTemplateModel): Map<string, any>;
    static toString(instance: InvoiceTemplateModel): string;
}
export interface GridAreaModel extends GridsterItem {
    id: any;
    cols: number;
    rows: number;
    x: number;
    y: number;
    isEmpty?: boolean;
    lineId?: string;
    companyInfoId?: string;
    customFieldsId?: string;
    saleAdditionalInfoId?: string;
}
export type CustomFieldGridAreaModel = GridAreaModel & {
    name: string;
};
export declare class InvoiceComponentTemplateModel {
    titleColor: string;
    colorEven: string;
    colorOdd: string;
    fontColor: string;
    borderColor: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any, ...params: any[]): InvoiceComponentTemplateModel;
    static toMap(instance: InvoiceComponentTemplateModel): Map<string, any>;
}
export declare class InvoiceFullInfoTemplateModel extends InvoiceComponentTemplateModel {
    saleHeader: string;
    dateHeader: string;
    dueDateHeader: string;
    termsHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): InvoiceFullInfoTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: InvoiceFullInfoTemplateModel): Map<string, any>;
}
export declare class InvoiceAdditionalInfoTemplateModel extends InvoiceComponentTemplateModel {
    id: string;
    dueDateHeader: string;
    termsHeader: string;
    salesRepHeader: string;
    shipDateHeader: string;
    shipMethodHeader: string;
    fobHeader: string;
    trackingNumberHeader: string;
    poNumberHeader: string;
    otherHeader: string;
    additionalInfo: GridAreaModel[];
    static fromJSON(jsonTemplate: any, defaultTemplate: any): InvoiceAdditionalInfoTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: InvoiceAdditionalInfoTemplateModel): Map<string, any>;
}
export declare class CompanyInfoTemplateModel extends InvoiceComponentTemplateModel {
    id: string;
    companyInfoHeader: string;
    hideHeader: boolean;
    companyInfoRows: CompanyInfoRowsEnum[];
    static fromJSON(jsonTemplate: any, defaultTemplate: any): CompanyInfoTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: CompanyInfoTemplateModel): Map<string, any>;
}
export declare class InvoiceItemTableTemplateModel extends InvoiceComponentTemplateModel {
    lineNumHeader: string;
    itemHeader: string;
    descriptionHeader: string;
    quantityHeader: string;
    rateHeader: string;
    amountHeader: string;
    taxableHeader: string;
    skuHeader: string;
    serviceDateHeader: string;
    categoryClassHeader: string;
    other1Header: string;
    other2Header: string;
    itemTable: GridAreaModel[];
    totals: InvoiceItemsTableTotalsEnum[];
    hideCustomerMemo: boolean;
    customerMemoColor: string;
    autoColumnWidths: boolean;
    autoTotalsWidth: boolean;
    totalsLabelColumnSpan: number;
    totalsAmountColumnSpan: number;
    private static readonly HEADER_KEYS;
    static fromJSON(jsonTemplate: Partial<InvoiceItemTableTemplateModel>, itemTable: GridAreaModel[], totals: InvoiceItemsTableTotalsEnum[], defaultTemplate: Partial<InvoiceItemTableTemplateModel>): InvoiceItemTableTemplateModel;
    static toMap(instance: InvoiceItemTableTemplateModel): Map<string, any>;
}
export declare class InvoiceItemsRowsTemplateModel extends InvoiceComponentTemplateModel {
    lineNumHeader: string;
    itemHeader: string;
    descriptionHeader: string;
    quantityHeader: string;
    rateHeader: string;
    amountHeader: string;
    taxableHeader: string;
    skuHeader: string;
    serviceDateHeader: string;
    categoryClassHeader: string;
    other1Header: string;
    other2Header: string;
    itemTable: GridAreaModel[];
    autoColumnWidths: boolean;
    private static readonly HEADER_KEYS;
    static fromJSON(jsonTemplate: Partial<InvoiceItemsRowsTemplateModel>, defaultTemplate: Partial<InvoiceItemsRowsTemplateModel>): InvoiceItemsRowsTemplateModel;
    static toMap(instance: InvoiceItemsRowsTemplateModel): Map<string, any>;
}
export declare class InvoiceShortInfoTemplateModel extends InvoiceComponentTemplateModel {
    dateHeader: string;
    saleHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): InvoiceShortInfoTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: InvoiceShortInfoTemplateModel): Map<string, any>;
}
export declare class AddressTemplateModel extends InvoiceComponentTemplateModel {
    addressHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): AddressTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: AddressTemplateModel): Map<string, any>;
}
export declare class CustomFieldsTemplateModel extends InvoiceComponentTemplateModel {
    id: string;
    customFields: CustomFieldGridAreaModel[];
    constructor(id: string, customFields: CustomFieldGridAreaModel[], titleColor: string, colorEven: string, colorOdd: string, fontColor: string, borderColor: string);
    static fromJSON(jsonTemplate: any, defaultTemplate: any): CustomFieldsTemplateModel;
    static toMap(instance: CustomFieldsTemplateModel): Map<string, any>;
}
export declare class LineTemplateModel {
    id: string;
    color: string;
    width: number;
    style: InvoiceEmailPaymentLineStyleEnum;
    constructor(id: string, defaultColor: string, width?: number, style?: InvoiceEmailPaymentLineStyleEnum);
    static fromJSON(jsonTemplate: any): LineTemplateModel;
    static toMap(instance: LineTemplateModel): Map<string, any>;
}
export declare class TotalsTemplateModel extends InvoiceComponentTemplateModel {
    totals: InvoiceItemsTableTotalsEnum[];
    totalHeader: string;
    subtotalHeader: string;
    taxHeader: string;
    discountHeader: string;
    shippingCostHeader: string;
    appliedAmountHeader: string;
    amountDueHeader: string;
    tipHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): TotalsTemplateModel;
    static toMap(instance: TotalsTemplateModel): Map<string, any>;
}
export declare class CustomerMemoTemplateModel extends InvoiceComponentTemplateModel {
    static fromJSON(jsonTemplate: any, defaultTemplate: any): CustomerMemoTemplateModel & InvoiceComponentTemplateModel;
}
export declare class TextTemplateModel {
    id: string;
    content: string;
    constructor(id: string, content?: string);
    static fromJSON(jsonTemplate: any): TextTemplateModel;
    static toMap(instance: TextTemplateModel): Map<string, any>;
}
export declare class ShippingInfoTemplateModel extends InvoiceComponentTemplateModel {
    shipMethodHeader: string;
    trackingNumberHeader: string;
    shipDateHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): ShippingInfoTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: ShippingInfoTemplateModel): Map<string, any>;
}
export declare class CustomerNameTemplateModel extends InvoiceComponentTemplateModel {
    id: string;
    customerNameId: string;
    customerNameHeader: string;
    static fromJSON(jsonTemplate: any, defaultTemplate: any): CustomerNameTemplateModel & InvoiceComponentTemplateModel;
    static toMap(instance: CustomerNameTemplateModel): Map<string, any>;
}
