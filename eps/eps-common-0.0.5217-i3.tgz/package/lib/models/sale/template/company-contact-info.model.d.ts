export declare class CompanyContactInfoModel {
    email: string;
    phone: string;
    website: string;
    formattedPhone: string;
}
