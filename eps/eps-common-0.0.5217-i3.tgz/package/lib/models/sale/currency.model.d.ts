export declare class CurrencyModel {
    id: number;
    code: string;
    name?: string;
    constructor(obj: {
        id: number;
        code: string;
        name?: string;
    });
    get stringValue(): string;
}
