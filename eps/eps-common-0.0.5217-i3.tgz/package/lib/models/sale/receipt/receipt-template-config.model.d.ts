import { ReceiptPrintWidthEnum } from "../../../enums/companymanagement/companysettings/receipt-print-width.enum";
import { ReceiptTemplateComponentEnum } from "../../../enums/companymanagement/companysettings/receipt-template-component.enum";
import { ReceiptTemplateFieldEnum } from "../../../enums/companymanagement/companysettings/receipt-template-field.enum";
export declare class ReceiptTemplateModel {
    width: ReceiptPrintWidthEnum;
    components: ReceiptTemplateComponentEnum[];
    fields: ReceiptTemplateFieldEnum[];
    message: string;
    static fromJSON(json: any): ReceiptTemplateModel;
    static toJSON(config: ReceiptTemplateModel): string;
}
