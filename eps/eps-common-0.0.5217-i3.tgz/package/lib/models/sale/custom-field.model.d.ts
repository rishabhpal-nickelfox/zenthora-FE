export declare class CustomFieldModel {
    name: string;
    value: string;
    static fromJSON(json: any): CustomFieldModel;
}
