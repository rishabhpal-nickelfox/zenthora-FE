import { CountryISOEnum } from "../../enums/utils/country-iso.enum";
export declare class AddressModel {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: CountryISOEnum;
    constructor(country?: CountryISOEnum, zip?: string, state?: string, city?: string, street?: string);
}
export declare function convertJSONToAddress(json: any): any;
export declare function convertAddressToJSON(address: AddressModel): {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: CountryISOEnum;
};
export interface BillingAddress {
    firstName: string;
    lastName: string;
    companyName: string;
    address1: string;
    address2: string;
    city: string;
    zip: string;
    state: string;
    country: CountryISOEnum;
    phone: string;
    email: string;
}
