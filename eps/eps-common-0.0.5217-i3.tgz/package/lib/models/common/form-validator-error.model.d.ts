import { Moment } from 'moment';
import { CountryISOEnum } from "../../enums/utils/country-iso.enum";
export declare class FormValidatorErrorModel {
    label: string;
    constructor(label: string);
}
export declare class FormValidatorMaxLengthErrorModel extends FormValidatorErrorModel {
    maxlength: number;
    constructor(label: string, maxlength: number);
}
export declare class FormValidatorMinLengthErrorModel extends FormValidatorErrorModel {
    minlength: number;
    constructor(label: string, minlength: number);
}
export declare class FormValidatorMinItemsErrorModel extends FormValidatorErrorModel {
    minSize: number;
    constructor(label: string, minSize: number);
}
export declare class FormValidatorExactLengthErrorModel extends FormValidatorErrorModel {
    length: number;
    constructor(label: string, minlength: number);
}
export declare class ServerErrorModel {
    error: string;
    constructor(error: string);
}
export declare class FormValidatorMustBeTheSameErrorModel extends FormValidatorErrorModel {
    sameAsLabel: string;
    constructor(label: string, sameAsLabel: string);
}
export declare class FormValidatorMaxValueErrorModel extends FormValidatorErrorModel {
    maxvalue: number;
    constructor(label: string, maxvalue: number);
}
export declare class FormValidatorMaxAmountErrorModel extends FormValidatorErrorModel {
    maxamount: number;
    currency: string;
    constructor(label: string, maxamount: number, currency: string);
}
export declare class FormValidatorMinValueErrorModel extends FormValidatorErrorModel {
    minvalue: number;
    constructor(label: string, minvalue: number);
}
export declare class FormValidatorMinValueStrictErrorModel extends FormValidatorErrorModel {
    minvalue: number;
    constructor(label: string, minvalue: number);
}
export declare class FormValidatorMinAmountErrorModel extends FormValidatorErrorModel {
    minamount: number;
    currency: string;
    constructor(label: string, minamount: number, currency: string);
}
export declare class FormValidatorDateValueErrorModel extends FormValidatorErrorModel {
    date: Moment;
    constructor(label: string, date: Moment);
}
export declare class FormValidatorZipErrorModel extends FormValidatorErrorModel {
    country: CountryISOEnum;
    constructor(label: string, country: CountryISOEnum);
}
