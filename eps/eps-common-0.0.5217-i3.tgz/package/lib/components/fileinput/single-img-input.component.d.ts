import { ControlValueAccessor } from '@angular/forms';
import { ComponentWithSubscriptions } from '../component-with-subscriptions';
import * as i0 from "@angular/core";
export declare class SingleImgInputComponent extends ComponentWithSubscriptions implements ControlValueAccessor {
    fileInput: any;
    filePreviewImg: any;
    maxWidth: string;
    maxHeight: string;
    maxFileSize: number;
    disabled: boolean;
    file: {
        value: string;
        type: string;
    };
    fileIsTooLarge: boolean;
    constructor();
    onChange: (value: any) => void;
    handleFileInput(file: File): void;
    get filePreview(): string;
    writeValue(obj: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    get value(): {
        value: string;
        type: string;
    };
    removeFile(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleImgInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SingleImgInputComponent, "app-single-img-input", never, { "maxWidth": { "alias": "maxWidth"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, false, never>;
}
