import { ChangeDetectorRef, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
import { ExtendedTypeaheadWithLoadDirective } from './extended-typeahead-with-load.directive';
import { ExtendedTypeaheadInputComponent } from './extended-typeahead-input.component';
import { DomSanitizer } from '@angular/platform-browser';
import { TypeaheadContainerComponent, TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import * as i0 from "@angular/core";
export declare class ExtendedTypeaheadWithLoadInputComponent extends ExtendedTypeaheadInputComponent implements ControlValueAccessor, OnInit {
    protected cd: ChangeDetectorRef;
    private sanitizer;
    protected renderer: Renderer2;
    pageableSource: (text: string, page: number) => Observable<any>;
    labelFormatter: (value: any, level?: number) => string;
    _typeahead: ExtendedTypeaheadWithLoadDirective;
    searchFieldValue: any;
    page: number;
    offset: (value: any) => string;
    constructor(cd: ChangeDetectorRef, sanitizer: DomSanitizer, renderer: Renderer2);
    get container(): TypeaheadContainerComponent;
    get loadMoreObject(): {
        _loadMore: boolean;
    };
    ngOnInit(): void;
    onSelect(e: TypeaheadMatch): void;
    onTouched(event: any): void;
    onChange(e: any): void;
    onLoadMore(): void;
    selectMatch(match: any, e: any): void;
    showSearchStringInInputField(): void;
    styleListFormatter(model: any, query: any): import("@angular/platform-browser").SafeHtml;
    makeContentFlat(content: any, level?: number): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtendedTypeaheadWithLoadInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtendedTypeaheadWithLoadInputComponent, "app-extended-typeahead-with-load-input", never, { "pageableSource": { "alias": "pageableSource"; "required": false; }; "labelFormatter": { "alias": "labelFormatter"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, false, never>;
}
