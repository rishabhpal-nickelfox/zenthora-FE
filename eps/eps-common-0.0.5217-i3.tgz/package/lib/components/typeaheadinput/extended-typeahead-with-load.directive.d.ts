import { EventEmitter } from '@angular/core';
import { ExtendedTypeaheadDirective } from './extended-typeahead.directive';
import { TypeaheadMatch } from "ngx-bootstrap/typeahead";
import * as i0 from "@angular/core";
export declare class ExtendedTypeaheadWithLoadDirective extends ExtendedTypeaheadDirective {
    loadMore: EventEmitter<any>;
    set extendedTypeaheadWithLoad(val: any);
    onChange(event: KeyboardEvent): void;
    addMatches(matches: TypeaheadMatch[]): void;
    onKeydown(event: KeyboardEvent): void;
    protected scrollToActive(code: any): void;
    private scrollUp;
    private scrollDown;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtendedTypeaheadWithLoadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtendedTypeaheadWithLoadDirective, "[extendedTypeaheadWithLoad]", ["qbo-typeahead-with-load"], { "extendedTypeaheadWithLoad": { "alias": "extendedTypeaheadWithLoad"; "required": false; }; }, { "loadMore": "loadMore"; }, never, never, false, never>;
}
