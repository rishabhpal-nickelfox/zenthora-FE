import { TypeaheadDirective } from 'ngx-bootstrap/typeahead';
import * as i0 from "@angular/core";
export declare class ExtendedTypeaheadDirective extends TypeaheadDirective {
    onFocus(): void;
    private openSearchHandler;
    set extendedTypeahead(val: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtendedTypeaheadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtendedTypeaheadDirective, "[extendedTypeahead]", never, { "extendedTypeahead": { "alias": "extendedTypeahead"; "required": false; }; }, {}, never, never, false, never>;
}
