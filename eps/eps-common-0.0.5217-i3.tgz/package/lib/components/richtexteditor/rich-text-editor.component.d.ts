import { ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import Quill from 'quill';
import * as i0 from "@angular/core";
export declare class RichTextEditorComponent implements ControlValueAccessor, OnDestroy, OnInit {
    private ch;
    value: string | null;
    isDisabled: boolean;
    editor: Quill;
    selectedAlignment: 'left' | 'center' | 'right';
    fontSizeMode: 'class' | 'style';
    defaultFontSize: number;
    defaultColor: string;
    allowedFontSizes: number[];
    placeholders: Map<string, string>;
    options: {
        selectFontSize?: boolean;
        selectFontColor?: boolean;
        selectBackgroundColor?: boolean;
        selectFontStyle?: boolean;
        selectListStyle?: boolean;
        selectAlignment?: boolean;
    };
    selectedFontSize: {
        label: string;
        value: string;
    };
    selectedColor: any;
    selectedBackgroundColor: string;
    fontSizes: any[];
    modules: {
        toolbar: boolean;
    };
    onChange: (_: any) => void;
    onTouched: () => void;
    constructor(ch: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    writeValue(value: string | null): void;
    onValueChange(newValue: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onEditorCreated(quill: Quill): void;
    applyFontSize(size: {
        label: string;
        value: string;
    }): void;
    applyFontColor(color: string): void;
    format(action: string): void;
    applyBackgroundColor(color: string): void;
    removeFormat(): void;
    syncControlsWithFormats(formats: any): void;
    toggleList(listType: 'bullet' | 'ordered'): void;
    applyAlignment(alignment: 'left' | 'center' | 'right'): void;
    insertPlaceholder(placeholder: string): void;
    isAlignmentSelected(alignment: 'left' | 'center' | 'right'): boolean;
    private configureFontSizeAttributor;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTextEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RichTextEditorComponent, "app-rich-text-editor", never, { "fontSizeMode": { "alias": "fontSizeMode"; "required": false; }; "defaultFontSize": { "alias": "defaultFontSize"; "required": false; }; "defaultColor": { "alias": "defaultColor"; "required": false; }; "allowedFontSizes": { "alias": "allowedFontSizes"; "required": false; }; "placeholders": { "alias": "placeholders"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, false, never>;
}
