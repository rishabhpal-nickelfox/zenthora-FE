import { OnInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ColorPickerComponent implements OnInit, ControlValueAccessor {
    label: string;
    includeNone: boolean;
    color: any;
    colors: string[];
    private readonly defaultColors;
    private static readonly NONE;
    onChange: (value: any) => void;
    onTouched: (value: any) => void;
    ngOnInit(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    get value(): any;
    changeColor(color: string): void;
    changeColorManual(color: string): void;
    isNone(color: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorPickerComponent, "app-color-picker", never, { "label": { "alias": "label"; "required": false; }; "includeNone": { "alias": "includeNone"; "required": false; }; }, {}, never, never, false, never>;
}
