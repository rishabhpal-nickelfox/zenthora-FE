import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ComponentWithSubscriptions implements OnDestroy {
    protected subscriptions: Subscription;
    constructor();
    ngOnDestroy(): void;
    isDefined(smth: any): boolean;
    protected onDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentWithSubscriptions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ComponentWithSubscriptions, never, never, {}, {}, never, never, true, never>;
}
