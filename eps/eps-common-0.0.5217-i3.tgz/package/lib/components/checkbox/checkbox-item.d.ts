export declare class CheckboxItem {
    value: string;
    label: string;
    checked: boolean;
    disabled: boolean;
    hint: string;
    constructor(value: any, label: any, checked: boolean, disabled?: boolean, hint?: string);
}
