import { OnChanges } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { HtmlSanitizerService } from '../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class RichTextViewerComponent implements OnChanges {
    private readonly htmlSanitizer;
    trustedValue: SafeHtml;
    value: string | SafeHtml;
    constructor(htmlSanitizer: HtmlSanitizerService);
    ngOnChanges(): void;
    private normalizeBreakingSpaces;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTextViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RichTextViewerComponent, "app-rich-text-viewer", never, { "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}
