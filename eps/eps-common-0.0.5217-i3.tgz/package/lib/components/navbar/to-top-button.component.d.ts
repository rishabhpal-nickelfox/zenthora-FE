import * as i0 from "@angular/core";
export declare class ToTopButtonComponent {
    show: boolean;
    constructor();
    scrollToTop(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToTopButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToTopButtonComponent, "app-to-top-button", never, {}, {}, never, never, false, never>;
}
