import { ChangeDetectorRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormControlErrorComponent {
    private cdr;
    _text: string;
    _hide: boolean;
    set text(value: any);
    constructor(cdr: ChangeDetectorRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlErrorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormControlErrorComponent, "ng-component", never, { "text": { "alias": "text"; "required": false; }; }, {}, never, never, false, never>;
}
