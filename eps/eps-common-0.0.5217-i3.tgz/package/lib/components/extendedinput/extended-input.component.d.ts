import { OnChanges } from '@angular/core';
import { ErrorService } from "../../utils/errorhandler/error.service";
import * as i0 from "@angular/core";
export declare class ExtendedInputComponent implements OnChanges {
    private errorService;
    labelText: string;
    required: boolean;
    inputErrors: any;
    errorDefs: any;
    hasError: boolean;
    verticalMode: boolean;
    labelContainerClass: string;
    labelClass: string;
    errors: {};
    constructor(errorService: ErrorService);
    ngOnChanges(changes: any): void;
    getErrorMsg(errorKey: any): any;
    get errorKeys(): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtendedInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtendedInputComponent, "app-extended-input", never, { "labelText": { "alias": "labelText"; "required": false; }; "required": { "alias": "required"; "required": false; }; "inputErrors": { "alias": "inputErrors"; "required": false; }; "errorDefs": { "alias": "errorDefs"; "required": false; }; "hasError": { "alias": "hasError"; "required": false; }; "verticalMode": { "alias": "verticalMode"; "required": false; }; "labelContainerClass": { "alias": "labelContainerClass"; "required": false; }; "labelClass": { "alias": "labelClass"; "required": false; }; }, {}, never, ["*"], false, never>;
}
