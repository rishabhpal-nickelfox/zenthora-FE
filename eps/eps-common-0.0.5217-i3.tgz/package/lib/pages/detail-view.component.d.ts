import { ElementRef, EventEmitter } from '@angular/core';
import { ComponentWithSubscriptions } from '../components/component-with-subscriptions';
import { Mask } from "../helpers/mask";
export declare abstract class DetailViewComponent extends ComponentWithSubscriptions {
    protected elementRef: ElementRef;
    dateConfig: import("ng2-date-picker").IDatePickerConfig;
    MASK: Mask;
    cancelEvent: EventEmitter<any>;
    constructor(elementRef: ElementRef);
    get nativeElement(): any;
    protected abstract onReInit(newData?: any): any;
    reInit(newData?: any): void;
    enumKeys(e: any): string[];
    print(printDiv: ElementRef): void;
    findInDictionaryById(dictionary: any, id: any): any;
    protected onCancel(): boolean;
    cancel(): boolean;
}
