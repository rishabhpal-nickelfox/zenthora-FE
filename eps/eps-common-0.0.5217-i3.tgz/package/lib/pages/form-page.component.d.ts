import { FormComponent } from './form.component';
import { ElementRef, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { FormPageStateService } from "../utils/form-page-state.service";
import { ErrorService } from "../utils/errorhandler/error.service";
import { ServerErrorService } from "../utils/server-error.service";
import * as i0 from "@angular/core";
export declare abstract class FormPageComponent extends FormComponent {
    formPageStateService: FormPageStateService;
    protected elementRef: ElementRef;
    errorService: ErrorService;
    serverErrorService?: ServerErrorService;
    saveEvent: EventEmitter<any>;
    saveAndNewEvent: EventEmitter<any>;
    protected closeAfterSubmit: boolean;
    constructor(formPageStateService: FormPageStateService, elementRef: ElementRef, errorService: ErrorService, serverErrorService?: ServerErrorService);
    private _submitLocked;
    get submitLocked(): boolean;
    isSubmitEnabled(): boolean;
    submit(): any;
    clearServerErrors(): void;
    afterSubmit(): void;
    lockSubmit(): void;
    unlockSubmit(): void;
    cancel(): boolean;
    saveAndClose(): void;
    saveAndNew(): void;
    reInit(newData?: any): void;
    focusFirst(): void;
    objectChanged(): boolean | Observable<boolean>;
    protected abstract onSubmit({ value }: {
        value: any;
    }): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormPageComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormPageComponent, never, never, {}, {}, never, never, true, never>;
}
