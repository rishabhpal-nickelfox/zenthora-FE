export declare const default_inactivity_time = 900;
export declare const default_inactivity_alert_time = 20;
export declare const SYSTEM_PREFIX = "EPS_";
export declare const alert_lifetime = 3000;
export declare const page_sizes: number[];
