import { ReceiptTemplateComponentEnum } from "./receipt-template-component.enum";
export declare enum ReceiptTemplateFieldEnum {
    COMPANY_LOGO = "COMPANY_LOGO",
    COMPANY_NAME = "COMPANY_NAME",
    COMPANY_ADDRESS = "COMPANY_ADDRESS",
    COMPANY_WEB_URL = "COMPANY_WEB_URL",
    COMPANY_PHONE = "COMPANY_PHONE",
    COMPANY_EMAIL = "COMPANY_EMAIL",
    DATETIME = "DATETIME",
    CUSTOMER_NAME = "CUSTOMER_NAME",
    CUSTOMER_EMAIL = "CUSTOMER_EMAIL",
    PO_NUMBER = "PO_NUMBER",
    MEMO = "MEMO",
    SALE_TABLE = "SALE_TABLE",
    SALE_TOTAL = "SALE_TOTAL",
    TAX = "TAX",
    DISCOUNT = "DISCOUNT",
    TIP = "TIP",
    SHIPPING_AMOUNT = "SHIPPING_AMOUNT",
    REFERENCE_NUMBER = "REFERENCE_NUMBER"
}
export declare const ReceiptTemplateFieldComponent: Record<ReceiptTemplateFieldEnum, ReceiptTemplateComponentEnum>;
export declare const ReceiptTemplateFieldLabel: Record<ReceiptTemplateFieldEnum, string>;
