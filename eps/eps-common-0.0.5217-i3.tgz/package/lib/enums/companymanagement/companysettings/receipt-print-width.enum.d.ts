export declare enum ReceiptPrintWidthEnum {
    PX185 = "PX185",
    LETTER = "LETTER"
}
export declare const ReceiptPrintWidthEnumLabel: Map<string, string>;
export declare const ReceiptPrintWidthEnumValue: Map<string, string>;
