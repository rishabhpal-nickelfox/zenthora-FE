export declare enum ReceiptTemplateComponentEnum {
    COMPANY_INFO = "COMPANY_INFO",
    SALE_INFO = "SALE_INFO",
    PAYMENT_INFO = "PAYMENT_INFO",
    SIGNATURE = "SIGNATURE",
    MESSAGE = "MESSAGE"
}
export declare const ReceiptTemplateComponentEnumLabel: Record<ReceiptTemplateComponentEnum, string>;
