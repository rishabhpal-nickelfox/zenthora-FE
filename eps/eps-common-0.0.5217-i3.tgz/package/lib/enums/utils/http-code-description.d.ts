import { HttpStatusCode } from '@angular/common/http';
export declare const HttpCodeDescriptions: Map<HttpStatusCode, string>;
