export declare enum CountryEnum {
    US = "US",
    CA = "CA"
}
export declare const CountryEnumValue: Map<string, string>;
