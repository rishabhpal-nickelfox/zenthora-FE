export declare const ReceiptTemplatePlaceholderEnumValue: Map<string, string>;
