export declare enum CurrencyEnum {
    USD = "USD",
    CAD = "CAD"
}
export declare const CurrencyEnumValue: Map<string, string>;
