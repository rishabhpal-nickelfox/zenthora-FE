export declare enum InvoiceItemsTableTotalsEnum {
    SUBTOTAL = "SUBTOTAL",
    TAX = "TAX",
    DISCOUNT = "DISCOUNT",
    SHIPPING_COST = "SHIPPING_COST",
    TOTAL = "TOTAL",
    APPLIED_AMOUNT = "APPLIED_AMOUNT",
    AMOUNT_DUE = "AMOUNT_DUE",
    TIP = "TIP"
}
export declare const InvoiceItemsTableTotalsEnumValue: Map<string, string>;
export declare const InvoiceItemsTableTotalsField: Map<InvoiceItemsTableTotalsEnum, string>;
export declare const InvoiceItemsTableTotalsOrdered: InvoiceItemsTableTotalsEnum[];
export declare const InvoiceItemsTableTotalsLegacyOrdered: InvoiceItemsTableTotalsEnum[];
