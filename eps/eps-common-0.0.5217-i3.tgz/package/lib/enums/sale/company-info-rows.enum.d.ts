export declare enum CompanyInfoRowsEnum {
    DISPLAY_NAME = "DISPLAY_NAME",
    COUNTRY = "COUNTRY",
    ZIP = "ZIP",
    STATE = "STATE",
    CITY = "CITY",
    STREET = "STREET",
    EMAIL = "EMAIL",
    PHONE = "PHONE",
    WEB_URL = "WEB_URL"
}
export declare const CompanyInfoRowsEnumValue: Map<string, string>;
