declare enum CompanySettingsTextTemplatePlaceholderEnum {
    CUSTOMER_NAME = "{CustomerName}",
    TOTAL = "{Total}",
    TERMS = "{Terms}",
    DUE_DATE = "{DueDate}",
    SHIPPING_COST = "{ShippingCost}",
    SHIP_DATE = "{ShipDate}",
    AMOUNT_DUE = "{AmountDue}",
    SHIP_METHOD = "{ShipMethod}",
    FOB = "{FOB}",
    PO_NUMBER = "{PoNumber}",
    CUSTOMER_NUMBER = "{CustomerNumber}"
}
export declare const ExtendedCompanySettingsTextTemplatePlaceholderEnum: {
    readonly DISPLAY_NAME: string;
    readonly COUNTRY: string;
    readonly ZIP: string;
    readonly STATE: string;
    readonly CITY: string;
    readonly STREET: string;
    readonly EMAIL: string;
    readonly PHONE: string;
    readonly WEB_URL: string;
    readonly CUSTOMER_NAME: CompanySettingsTextTemplatePlaceholderEnum.CUSTOMER_NAME;
    readonly TOTAL: CompanySettingsTextTemplatePlaceholderEnum.TOTAL;
    readonly TERMS: CompanySettingsTextTemplatePlaceholderEnum.TERMS;
    readonly DUE_DATE: CompanySettingsTextTemplatePlaceholderEnum.DUE_DATE;
    readonly SHIPPING_COST: CompanySettingsTextTemplatePlaceholderEnum.SHIPPING_COST;
    readonly SHIP_DATE: CompanySettingsTextTemplatePlaceholderEnum.SHIP_DATE;
    readonly AMOUNT_DUE: CompanySettingsTextTemplatePlaceholderEnum.AMOUNT_DUE;
    readonly SHIP_METHOD: CompanySettingsTextTemplatePlaceholderEnum.SHIP_METHOD;
    readonly FOB: CompanySettingsTextTemplatePlaceholderEnum.FOB;
    readonly PO_NUMBER: CompanySettingsTextTemplatePlaceholderEnum.PO_NUMBER;
    readonly CUSTOMER_NUMBER: CompanySettingsTextTemplatePlaceholderEnum.CUSTOMER_NUMBER;
};
export declare const ExtendedCompanySettingsTextTemplatePlaceholderEnumValue: Map<string, string>;
export {};
