export declare enum PaymentStatusEnum {
    UNPAID = "UNPAID",
    PAID = "PAID",
    CANCELLED = "CANCELLED",
    PARTIALLY_PAID = "PARTIALLY_PAID"
}
export declare const PaymentStatusEnumValue: Map<string, string>;
