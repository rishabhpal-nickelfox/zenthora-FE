export declare enum InvoiceEmailPaymentTemplateLogoSizeEnum {
    REAL = "REAL",
    S = "S",
    M = "M",
    L = "L"
}
export declare const InvoiceEmailPaymentTemplateLogoSizeEnumName: Map<string, string>;
export declare function getInvoiceEmailPaymentTemplateLogoWidth(value?: InvoiceEmailPaymentTemplateLogoSizeEnum | string): string;
