export declare enum InvoiceEmailPaymentTemplateComponentsEnum {
    COMPANY_INFO = "COMPANY_INFO",
    BILLING_ADDRESS = "BILLING_ADDRESS",
    SHIPPING_ADDRESS = "SHIPPING_ADDRESS",
    SHIPPING_INFO = "SHIPPING_INFO",
    LOGO = "LOGO",
    SALE_SHORT_INFO = "SALE_SHORT_INFO",
    SALE_ADDITIONAL = "SALE_ADDITIONAL",
    ITEMS = "ITEMS",
    ITEMS_ROWS = "ITEMS_ROWS",
    TOTALS = "TOTALS",
    CUSTOM_FIELDS = "CUSTOM_FIELDS",
    SALE_FULL_INFO = "SALE_FULL_INFO",
    CUSTOMER_MEMO = "CUSTOMER_MEMO",
    CUSTOMER_NAME = "CUSTOMER_NAME",
    TEXT = "TEXT",
    LINE = "LINE"
}
export declare const InvoiceEmailPaymentTemplateComponentsEnumValue: Map<string, string>;
export declare const InvoiceEmailPaymentTemplateComponentsWithDynamicHeight: InvoiceEmailPaymentTemplateComponentsEnum[];
export declare const InvoiceEmailPaymentTemplateComponentsMultiple: InvoiceEmailPaymentTemplateComponentsEnum[];
