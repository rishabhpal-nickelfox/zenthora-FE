export declare enum InvoiceItemsTableColumnsEnum {
    LINE_NUM = "LINE_NUM",
    ITEM = "ITEM",
    DESCRIPTION = "DESCRIPTION",
    QTY = "QTY",
    RATE = "RATE",
    AMOUNT = "AMOUNT",
    TAX = "TAX",
    SKU = "SKU",
    SERVICE_DATE = "SERVICE_DATE",
    CATEGORY_CLASS = "CATEGORY_CLASS",
    OTHER_1 = "OTHER_1",
    OTHER_2 = "OTHER_2"
}
export declare const InvoiceItemsTableColumnsEnumValue: Map<string, string>;
export declare const InvoiceItemsTableAdvancedColumns: InvoiceItemsTableColumnsEnum[];
