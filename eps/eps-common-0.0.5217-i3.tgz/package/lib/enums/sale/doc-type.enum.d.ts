export declare enum DocTypeEnum {
    INVOICE = "INVOICE",
    SALES_ORDER = "SALES_ORDER",
    DEPOSIT = "DEPOSIT",
    PAYMENT_FORM = "PAYMENT_FORM"
}
export declare const DocTypeEnumValue: Map<string, string>;
