export declare enum InvoiceEmailPaymentLineStyleEnum {
    SOLID = "SOLID",
    DOTTED = "DOTTED",
    DASHED = "DASHED",
    DOUBLE = "DOUBLE"
}
export declare const InvoiceEmailPaymentLineStyleEnumValue: Map<string, string>;
