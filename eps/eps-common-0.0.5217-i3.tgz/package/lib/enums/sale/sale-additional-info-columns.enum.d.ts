export declare enum SaleAdditionalInfoColumnsEnum {
    DUE_DATE = "DUE_DATE",
    TERMS = "TERMS",
    SALES_REP = "SALES_REP",
    SHIP_DATE = "SHIP_DATE",
    SHIP_METHOD = "SHIP_METHOD",
    FOB = "FOB",
    TRACKING_NUMBER = "TRACKING_NUMBER",
    PO_NUMBER = "PO_NUMBER",
    OTHER = "OTHER"
}
export declare const SaleAdditionalInfoColumnsEnumValue: Map<string, string>;
export declare const SaleAdditionalAdvancedColumns: SaleAdditionalInfoColumnsEnum[];
