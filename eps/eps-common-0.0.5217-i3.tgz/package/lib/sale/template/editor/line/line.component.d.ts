import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { LineViewService } from './line-view.service';
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class LineComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: LineViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    private _template;
    constructor(viewService: LineViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<LineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LineComponent, "app-invoice-email-payment-template-line", never, {}, {}, never, never, false, never>;
}
