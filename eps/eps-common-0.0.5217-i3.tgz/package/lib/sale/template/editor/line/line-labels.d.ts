export declare const LineLabels: {
    readonly Color: "Color";
    readonly Width: "Width";
    readonly Style: "Style";
};
