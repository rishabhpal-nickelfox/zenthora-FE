import { EventEmitter } from '@angular/core';
import { LineTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import { InvoiceEmailPaymentLineStyleEnum } from "../../../../enums/sale/invoice-email-payment-line-style.enum";
import * as i0 from "@angular/core";
export declare class LineViewService {
    private _lineTemplates;
    private _defaultColor;
    settingsChanged: EventEmitter<string[]>;
    get templates(): LineTemplateModel[];
    initTemplates(lineTemplates: LineTemplateModel[], defaultLineColor: string): void;
    getTemplate(lineId: string): LineTemplateModel;
    updateTemplate(lineId: string, color: string, width: number, style: InvoiceEmailPaymentLineStyleEnum): void;
    static getLineCss(color: string, width: number, style: InvoiceEmailPaymentLineStyleEnum): string;
    createLine(defaultColor: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LineViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LineViewService>;
}
