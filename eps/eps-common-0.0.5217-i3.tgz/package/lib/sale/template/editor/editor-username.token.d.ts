import { InjectionToken } from '@angular/core';
export declare const EDITOR_USERNAME: InjectionToken<string>;
