import { InvoiceItemsTableTotalsEnum } from '../../../../enums/sale/invoice-items-table-totals.enum';
import { SaleEmailTemplateData } from '../../../../models/sale/template/sale-email-template-data.model';
export declare class InvoiceTotalsPreviewHelper {
    static getRows(data: SaleEmailTemplateData, totals: InvoiceItemsTableTotalsEnum[]): {
        id: InvoiceItemsTableTotalsEnum;
        label: string;
        amount: number;
    }[];
    private static getLabel;
}
