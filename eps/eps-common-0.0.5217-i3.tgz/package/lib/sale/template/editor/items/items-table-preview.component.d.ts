import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { GridAreaModel } from '../../../../models/sale/template/invoice-template.model';
import { ItemsGridLayoutCommonService } from './items-grid-layout-common.service';
import * as i0 from "@angular/core";
export declare abstract class ItemsTablePreviewComponent<TViewService extends ItemsGridLayoutCommonService> extends InvoiceEmailTemplateAbstractComponent {
    previewLayout: GridAreaModel[];
    previewAutoColumnWidths: boolean;
    protected abstract viewService: TViewService;
    getColumns(): string | null;
    protected get currentLayout(): GridAreaModel[];
    protected get currentAutoColumnWidths(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemsTablePreviewComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemsTablePreviewComponent<any>, never, never, { "previewLayout": { "alias": "previewLayout"; "required": false; }; "previewAutoColumnWidths": { "alias": "previewAutoColumnWidths"; "required": false; }; }, {}, never, never, true, never>;
}
