import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { SafeHtml } from '@angular/platform-browser';
import { InvoiceItemsDataService } from '../invoice-items-data.service';
import { TotalsViewService } from './totals-view.service';
import { CountryEnum } from "../../../../../enums/utils/county.enum";
import { TotalsTemplateModel } from "../../../../../models/sale/template/invoice-template.model";
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import { InvoiceItemsTableTotalsEnum } from "../../../../../enums/sale/invoice-items-table-totals.enum";
import * as i0 from "@angular/core";
declare class InvoiceInfoTemplateModel {
}
export declare class TotalsComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: TotalsViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    styles: SafeHtml;
    currency: {
        code: string;
    };
    qboCountry: CountryEnum;
    totalsTemplateModel: TotalsTemplateModel;
    protected readonly data: InvoiceInfoTemplateModel;
    constructor(viewService: TotalsViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    get isUS(): boolean;
    ngOnInit(): void;
    protected readonly InvoiceItemsTableTotalsEnum: typeof InvoiceItemsTableTotalsEnum;
    private updateStyles;
    get orderedTotals(): InvoiceItemsTableTotalsEnum[];
    protected readonly Object: ObjectConstructor;
    protected readonly TotalsViewService: typeof TotalsViewService;
    protected readonly InvoiceItemsDataService: typeof InvoiceItemsDataService;
    static ɵfac: i0.ɵɵFactoryDeclaration<TotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TotalsComponent, "app-invoice-email-payment-template-totals", never, {}, {}, never, never, false, never>;
}
export {};
