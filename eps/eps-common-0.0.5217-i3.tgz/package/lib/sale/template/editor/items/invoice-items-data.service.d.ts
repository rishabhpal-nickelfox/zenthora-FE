import { SaleEmailTemplateData } from "../../../../models/sale/template/sale-email-template-data.model";
export declare class InvoiceItemsDataService {
    static get templateData(): SaleEmailTemplateData;
}
