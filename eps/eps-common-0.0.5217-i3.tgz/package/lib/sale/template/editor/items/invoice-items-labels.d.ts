export declare const InvoiceItemsLabels: {
    readonly Header: "Header";
};
