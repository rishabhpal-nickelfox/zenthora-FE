import { ChangeDetectorRef, OnInit } from '@angular/core';
import { ItemsTablePreviewComponent } from '../items-table-preview.component';
import { SafeHtml } from "@angular/platform-browser";
import { InvoiceItemsTableColumnsEnum } from "../../../../../enums/sale/invoice-items-table-columns.enum";
import { CountryEnum } from "../../../../../enums/utils/county.enum";
import { GridAreaModel } from "../../../../../models/sale/template/invoice-template.model";
import { InvoiceItemsTableTotalsEnum } from '../../../../../enums/sale/invoice-items-table-totals.enum';
import { InvoiceItemsTableTemplateLayoutService } from "./invoice-items-table-template-layout.service";
import { ObjectHelper } from "../../../../../helpers/object.helper";
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import { SaleEmailTemplateData } from "../../../../../models/sale/template/sale-email-template-data.model";
import * as i0 from "@angular/core";
export declare class InvoiceItemsComponent extends ItemsTablePreviewComponent<InvoiceItemsTableTemplateLayoutService> implements OnInit {
    protected viewService: InvoiceItemsTableTemplateLayoutService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    styles: SafeHtml;
    readonly InvoiceItemsTableColumnsEnum: typeof InvoiceItemsTableColumnsEnum;
    currency: {
        code: string;
    };
    qboCountry: CountryEnum;
    totalsRows: {
        id: InvoiceItemsTableTotalsEnum;
        label: string;
        amount: number;
    }[];
    private _layout;
    private _totals;
    protected readonly data: SaleEmailTemplateData;
    constructor(viewService: InvoiceItemsTableTemplateLayoutService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    get isUS(): boolean;
    ngOnInit(): void;
    show(colId: any): boolean;
    getOrder(colId: any): number;
    isTotalRowPresented(row: string): boolean;
    protected readonly InvoiceItemsTableTotalsEnum: typeof InvoiceItemsTableTotalsEnum;
    private updateStyles;
    get layout(): GridAreaModel[];
    get totals(): InvoiceItemsTableTotalsEnum[];
    updateLayout(): void;
    getMemoTotalsColumns(): import("@angular/platform-browser").SafeStyle;
    getTotalsColumns(): import("@angular/platform-browser").SafeStyle;
    updateTotals(): void;
    protected readonly ObjectHelper: typeof ObjectHelper;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceItemsComponent, "app-invoice-email-payment-template-invoice-items", never, {}, {}, never, never, false, never>;
}
