import { ChangeDetectorRef, OnInit } from '@angular/core';
import { ItemsTablePreviewComponent } from '../items-table-preview.component';
import { SafeHtml } from '@angular/platform-browser';
import { InvoiceItemRowsTemplateLayoutService } from './invoice-item-rows-template-layout.service';
import { InvoiceItemsTableColumnsEnum } from "../../../../../enums/sale/invoice-items-table-columns.enum";
import { CountryEnum } from "../../../../../enums/utils/county.enum";
import { GridAreaModel } from "../../../../../models/sale/template/invoice-template.model";
import { SaleEmailTemplateData } from "../../../../../models/sale/template/sale-email-template-data.model";
import { ObjectHelper } from "../../../../../helpers/object.helper";
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class InvoiceItemRowsComponent extends ItemsTablePreviewComponent<InvoiceItemRowsTemplateLayoutService> implements OnInit {
    protected viewService: InvoiceItemRowsTemplateLayoutService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    styles: SafeHtml;
    currency: {
        code: string;
    };
    qboCountry: CountryEnum;
    private _layout;
    protected readonly data: SaleEmailTemplateData;
    constructor(viewService: InvoiceItemRowsTemplateLayoutService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    get isUS(): boolean;
    ngOnInit(): void;
    show(colId: any): boolean;
    getOrder(colId: any): number;
    private updateStyles;
    get layout(): GridAreaModel[];
    updateLayout(): void;
    protected readonly InvoiceItemsTableColumnsEnum: typeof InvoiceItemsTableColumnsEnum;
    protected readonly ObjectHelper: typeof ObjectHelper;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceItemRowsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceItemRowsComponent, "app-invoice-email-payment-template-invoice-items-rows", never, {}, {}, never, never, false, never>;
}
