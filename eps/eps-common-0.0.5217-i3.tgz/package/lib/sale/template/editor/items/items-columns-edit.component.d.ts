import { AfterViewInit, ChangeDetectorRef, ElementRef } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { FormControl } from '@angular/forms';
import { FormPageComponent } from '../../../../pages/form-page.component';
import { GridAreaModel } from '../../../../models/sale/template/invoice-template.model';
import { ItemsGridLayoutCommonService } from './items-grid-layout-common.service';
import * as i0 from "@angular/core";
export interface ItemsColumnField {
    control: FormControl<string>;
    property: string;
}
export declare abstract class ItemsColumnsEditComponent<TViewService extends ItemsGridLayoutCommonService> extends FormPageComponent implements AfterViewInit {
    layout: GridAreaModel[];
    protected abstract readonly columnFields: Map<string, ItemsColumnField>;
    protected _autoColumnWidths: FormControl<boolean>;
    protected columnsProbe: {
        updateLayout(): void;
    };
    protected columnsProbeRef: ElementRef<HTMLElement>;
    private readonly _measuredWidthPx;
    private _syncTimer;
    private _headerHeightTimer;
    private _stopResize;
    private _viewService;
    protected readonly ch: ChangeDetectorRef;
    get viewService(): TViewService;
    set viewService(value: TViewService);
    ngAfterViewInit(): void;
    protected onDestroy(): void;
    canAddColumn(key: string): boolean;
    addColumn(key: string): void;
    deleteColumn(key: string): void;
    columnTitle(columnId: string, control: FormControl<string>): string;
    syncHeaderHeights(): void;
    protected initColumns(layout: GridAreaModel[]): void;
    protected saveColumns(): void;
    protected columnWidthPx(item: GridAreaModel): number;
    protected onColumnWidthsChanged(): void;
    protected onColumnDrop(event: CdkDragDrop<GridAreaModel[]>): void;
    protected startResize(event: PointerEvent, index: number): void;
    protected trackPointerDrag(move: (event: PointerEvent) => void, done?: () => void): void;
    protected syncColumnWidths(): void;
    private onColumnsChanged;
    private applyColumnWidths;
    private measurePreviewWidths;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemsColumnsEditComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemsColumnsEditComponent<any>, never, never, {}, {}, never, never, true, never>;
}
