export declare const TextLabels: {
    readonly Color: "Color";
    readonly Size: "Size";
    readonly Text: "Text";
};
