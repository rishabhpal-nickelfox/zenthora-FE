import { EventEmitter } from '@angular/core';
import { TextTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class TextViewService {
    protected _templates: TextTemplateModel[];
    private _defaultColor;
    settingsChanged: EventEmitter<string[]>;
    get templates(): TextTemplateModel[];
    initTemplates(textTemplates: TextTemplateModel[], defaultLineColor: string): void;
    getTemplate(textId: string): TextTemplateModel;
    updateTemplate(textId: string, content: string): void;
    createText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TextViewService>;
}
