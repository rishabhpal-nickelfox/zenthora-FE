import { OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { TextViewService } from './text-view.service';
import { HtmlSanitizerService } from "../../../../utils/html-sanitizer.service";
import * as i0 from "@angular/core";
export declare class TextComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: TextViewService;
    private htmlSanitizer;
    protected ch: ChangeDetectorRef;
    private _template;
    protected safeHtmlContent: SafeHtml;
    constructor(viewService: TextViewService, htmlSanitizer: HtmlSanitizerService, ch: ChangeDetectorRef);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextComponent, "app-invoice-email-payment-template-text", never, {}, {}, never, never, false, never>;
}
