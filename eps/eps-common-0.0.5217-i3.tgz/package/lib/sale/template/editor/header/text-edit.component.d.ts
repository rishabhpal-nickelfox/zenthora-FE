import { ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { SafeStyle } from '@angular/platform-browser';
import { FormControl, FormGroup } from '@angular/forms';
import { TextViewService } from './text-view.service';
import { FormPageStateService } from "../../../../utils/form-page-state.service";
import { FormPageComponent } from "../../../../pages/form-page.component";
import { ErrorService } from "../../../../utils/errorhandler/error.service";
import { NbDialogRef } from "@nebular/theme";
import { InvoiceEmailPaymentTemplateComponentsEnum } from "../../../../enums/sale/invoice-email-payment-template-components.enum";
import * as i0 from "@angular/core";
export declare class TextEditComponent extends FormPageComponent implements OnInit {
    formPageStateService: FormPageStateService;
    protected elementRef: ElementRef;
    errorService: ErrorService;
    protected ch: ChangeDetectorRef;
    protected dialogRef: NbDialogRef<TextEditComponent>;
    readonly Labels: {
        readonly Color: "Color";
        readonly Size: "Size";
        readonly Text: "Text";
    };
    styles: SafeStyle;
    readonly MAX_LENGTH: {
        text: number;
    };
    defaultFontSize: number;
    defaultColor: string;
    protected _content: FormControl<string>;
    private _form;
    private textId;
    afterInit: () => void;
    constructor(formPageStateService: FormPageStateService, elementRef: ElementRef, errorService: ErrorService, ch: ChangeDetectorRef, dialogRef: NbDialogRef<TextEditComponent>);
    private _viewService;
    get viewService(): TextViewService;
    set viewService(value: TextViewService);
    ngOnInit(): void;
    getForm(): FormGroup;
    protected onReInit(textId: string): void;
    close(): void;
    protected onSubmit({ value }: {
        value: any;
    }): void;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnumValue: Map<string, string>;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnum: typeof InvoiceEmailPaymentTemplateComponentsEnum;
    protected readonly CompanySettingsTextTemplatePlaceholderEnumValue: Map<string, string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditComponent, "app-invoice-email-payment-template-text-edit", never, {}, {}, never, never, false, never>;
}
