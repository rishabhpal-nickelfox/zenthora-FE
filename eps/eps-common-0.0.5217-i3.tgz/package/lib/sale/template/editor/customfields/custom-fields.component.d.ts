import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { CustomFieldsTableTemplateLayoutService } from './custom-fields-table-template-layout.service';
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CustomFieldsComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: CustomFieldsTableTemplateLayoutService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    private _template;
    constructor(viewService: CustomFieldsTableTemplateLayoutService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    get customFields(): import("../../../../models/sale/template/invoice-template.model").CustomFieldGridAreaModel[];
    private updateStyles;
    getOrder(colId: any): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomFieldsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomFieldsComponent, "app-invoice-email-payment-template-custom-fields", never, {}, {}, never, never, false, never>;
}
