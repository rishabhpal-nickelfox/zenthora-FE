export declare const CustomFieldsLabels: {
    readonly Header: "Header";
};
