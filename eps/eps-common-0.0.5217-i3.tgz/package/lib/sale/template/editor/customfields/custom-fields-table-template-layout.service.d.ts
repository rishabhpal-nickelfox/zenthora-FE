import { InvoiceEmailTemplateLayoutCommonService } from '../invoice-email-template-layout-common.service';
import { CustomFieldGridAreaModel, CustomFieldsTemplateModel, InvoiceComponentTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class CustomFieldsTableTemplateLayoutService extends InvoiceEmailTemplateLayoutCommonService {
    protected _templates: CustomFieldsTemplateModel[];
    private _defaultTemplate;
    private readonly _defaultCustomFields;
    private _customFieldsEnabled;
    static readonly CUSTOM_FIELDS_ROW_MAX_SIZE = 6;
    /**
     * Optional list of custom field names available for the company, used to
     * suggest header values in the editor. Empty by default (free-text input).
     */
    availableCustomFieldNames: string[];
    constructor();
    addItem(layout: CustomFieldGridAreaModel[], name: string): boolean;
    getTemplate(customFieldTemplateId: string): CustomFieldsTemplateModel;
    initTemplates(templates: CustomFieldsTemplateModel[], defaultTemplate: InvoiceComponentTemplateModel): void;
    getMinimumCols(): number;
    get templates(): CustomFieldsTemplateModel[];
    createCustomFields(defaultTemplate: InvoiceComponentTemplateModel): string;
    updateTemplate(customFieldsId: string, fontColor: string, borderColor: string, colorOdd: string, titleColor: string, layout: CustomFieldGridAreaModel[]): void;
    get customFieldsEnabled(): boolean;
    set customFieldsEnabled(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomFieldsTableTemplateLayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomFieldsTableTemplateLayoutService>;
}
