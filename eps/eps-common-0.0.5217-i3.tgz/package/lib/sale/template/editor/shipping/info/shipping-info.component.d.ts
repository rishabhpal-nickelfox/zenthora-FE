import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { ShippingInfoViewService } from './shipping-info-view.service';
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class ShippingInfoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: ShippingInfoViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    constructor(viewService: ShippingInfoViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShippingInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShippingInfoComponent, "app-invoice-email-payment-template-shipping-info", never, {}, {}, never, never, false, never>;
}
