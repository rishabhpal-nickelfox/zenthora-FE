import { InvoiceEmailTemplateViewCommonService } from '../../invoice-email-template-view-common.service';
import { AddressTemplateModel, InvoiceComponentTemplateModel } from "../../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class ShippingAddressViewService extends InvoiceEmailTemplateViewCommonService {
    private _addressHeader;
    get template(): AddressTemplateModel;
    initTemplate(value: AddressTemplateModel, defaultTemplate: InvoiceComponentTemplateModel): void;
    get addressHeader(): string;
    set addressHeader(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<ShippingAddressViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShippingAddressViewService>;
}
