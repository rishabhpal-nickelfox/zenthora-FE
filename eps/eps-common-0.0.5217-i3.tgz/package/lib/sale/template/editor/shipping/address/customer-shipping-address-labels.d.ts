export declare const CustomerShippingAddressLabels: {
    readonly Header: "Header";
};
