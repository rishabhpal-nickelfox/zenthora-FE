export declare const ShippingInfoLabels: {
    readonly Header: "Header";
};
