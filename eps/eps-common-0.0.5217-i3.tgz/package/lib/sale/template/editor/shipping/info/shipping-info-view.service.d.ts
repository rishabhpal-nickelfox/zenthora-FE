import { InvoiceEmailTemplateViewCommonService } from '../../invoice-email-template-view-common.service';
import { InvoiceComponentTemplateModel, ShippingInfoTemplateModel } from "../../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class ShippingInfoViewService extends InvoiceEmailTemplateViewCommonService {
    private _shipMethodHeader;
    private _trackingNumberHeader;
    private _shipDateHeader;
    get shipMethodHeader(): string;
    set shipMethodHeader(value: string);
    get trackingNumberHeader(): string;
    set trackingNumberHeader(value: string);
    get shipDateHeader(): string;
    set shipDateHeader(value: string);
    get template(): ShippingInfoTemplateModel;
    initTemplate(value: ShippingInfoTemplateModel, defaultTemplate: InvoiceComponentTemplateModel): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShippingInfoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShippingInfoViewService>;
}
