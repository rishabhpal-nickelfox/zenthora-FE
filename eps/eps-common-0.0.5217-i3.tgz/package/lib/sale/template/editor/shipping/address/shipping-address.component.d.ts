import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { ShippingAddressViewService } from './shipping-address-view.service';
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class ShippingAddressComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: ShippingAddressViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    readonly shippingAddress = "Sasha Tillou\nFreeman Sporting Goods\n370 Easy St.\nMiddlefield, CA  94482";
    constructor(viewService: ShippingAddressViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShippingAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShippingAddressComponent, "app-invoice-email-payment-template-shipping-address", never, {}, {}, never, never, false, never>;
}
