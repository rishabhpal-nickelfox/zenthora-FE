import { ElementRef, OnInit } from '@angular/core';
import { SafeStyle } from '@angular/platform-browser';
import { InvoiceFullInfoViewService } from './invoice-full-info-view.service';
import { FormControl, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormPageStateService } from "../../../../../utils/form-page-state.service";
import { FormPageComponent } from "../../../../../pages/form-page.component";
import { ErrorService } from "../../../../../utils/errorhandler/error.service";
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import { InvoiceEmailPaymentTemplateComponentsEnum } from "../../../../../enums/sale/invoice-email-payment-template-components.enum";
import * as i0 from "@angular/core";
export declare class InvoiceFullInfoEditComponent extends FormPageComponent implements OnInit {
    formPageStateService: FormPageStateService;
    protected elementRef: ElementRef;
    errorService: ErrorService;
    private _activeModal;
    private readonly htmlSanitizer;
    protected styles: SafeStyle;
    readonly MAX_LENGTH: {
        HEADER: number;
    };
    readonly Labels: {
        readonly Header: "Header";
    };
    protected _saleHeader: FormControl<string>;
    protected _dateHeader: FormControl<string>;
    protected _dueDateHeader: FormControl<string>;
    protected _termsHeader: FormControl<string>;
    protected _borderColor: FormControl<string>;
    protected _fontColor: FormControl<string>;
    protected _colorEven: FormControl<string>;
    protected _colorOdd: FormControl<string>;
    private _form;
    constructor(formPageStateService: FormPageStateService, elementRef: ElementRef, errorService: ErrorService, _activeModal: NgbActiveModal, htmlSanitizer: HtmlSanitizerService);
    private _viewService;
    get viewService(): InvoiceFullInfoViewService;
    set viewService(value: InvoiceFullInfoViewService);
    ngOnInit(): void;
    getForm(): FormGroup;
    protected onReInit(): void;
    close(): void;
    protected onSubmit({ value }: {
        value: any;
    }): void;
    get activeModal(): NgbActiveModal;
    private updateStyles;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnumValue: Map<string, string>;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnum: typeof InvoiceEmailPaymentTemplateComponentsEnum;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceFullInfoEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceFullInfoEditComponent, "app-invoice-email-payment-template-invoice-full-info-edit", never, {}, {}, never, never, false, never>;
}
