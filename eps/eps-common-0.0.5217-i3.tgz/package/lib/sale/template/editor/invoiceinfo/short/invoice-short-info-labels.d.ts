export declare const InvoiceShortInfoLabels: {
    readonly Header: "Header";
};
