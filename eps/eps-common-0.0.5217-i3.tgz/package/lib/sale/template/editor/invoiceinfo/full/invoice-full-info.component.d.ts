import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { InvoiceFullInfoViewService } from './invoice-full-info-view.service';
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class InvoiceFullInfoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: InvoiceFullInfoViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    constructor(viewService: InvoiceFullInfoViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceFullInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceFullInfoComponent, "app-invoice-email-payment-template-invoice-full-info", never, {}, {}, never, never, false, never>;
}
