import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { InvoiceShortInfoViewService } from './invoice-short-info-view.service';
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class InvoiceShortInfoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: InvoiceShortInfoViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    constructor(viewService: InvoiceShortInfoViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceShortInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceShortInfoComponent, "app-invoice-email-payment-template-invoice-short-info", never, {}, {}, never, never, false, never>;
}
