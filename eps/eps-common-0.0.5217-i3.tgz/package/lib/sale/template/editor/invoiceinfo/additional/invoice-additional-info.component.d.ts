import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../../invoice-email-template-abstract.component';
import { InvoiceAdditionalInfoLayoutService } from './invoice-additional-info-layout.service';
import { GridAreaModel } from '../../../../../models/sale/template/invoice-template.model';
import { HtmlSanitizerService } from '../../../../../utils/html-sanitizer.service';
import { SaleAdditionalInfoColumnsEnum } from '../../../../../enums/sale/sale-additional-info-columns.enum';
import * as i0 from "@angular/core";
export declare class InvoiceAdditionalInfoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: InvoiceAdditionalInfoLayoutService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    private _template;
    private _layout;
    constructor(viewService: InvoiceAdditionalInfoLayoutService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    get layout(): GridAreaModel[];
    show(columnId: SaleAdditionalInfoColumnsEnum): boolean;
    getOrder(columnId: SaleAdditionalInfoColumnsEnum): number;
    protected readonly SaleAdditionalInfoColumnsEnum: typeof SaleAdditionalInfoColumnsEnum;
    columns: {
        key: SaleAdditionalInfoColumnsEnum;
        getHeader: () => string;
        dataKey: string;
    }[];
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceAdditionalInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceAdditionalInfoComponent, "app-invoice-email-payment-template-invoice-additional-info", never, {}, {}, never, never, false, never>;
}
