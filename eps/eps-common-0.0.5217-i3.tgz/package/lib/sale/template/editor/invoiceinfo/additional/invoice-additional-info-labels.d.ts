export declare const InvoiceAdditionalInfoLabels: {
    readonly Header: "Header";
};
