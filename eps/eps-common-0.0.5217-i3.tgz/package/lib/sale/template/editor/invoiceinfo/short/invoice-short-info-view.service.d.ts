import { InvoiceEmailTemplateViewCommonService } from '../../invoice-email-template-view-common.service';
import { InvoiceComponentTemplateModel, InvoiceShortInfoTemplateModel } from "../../../../../models/sale/template/invoice-template.model";
import { DocTypeEnum } from "../../../../../enums/sale/doc-type.enum";
import * as i0 from "@angular/core";
export declare class InvoiceShortInfoViewService extends InvoiceEmailTemplateViewCommonService {
    private _saleType;
    private _saleHeaderDisplayed;
    get dateHeader(): string;
    set dateHeader(value: string);
    get saleHeader(): string;
    set saleHeader(value: string);
    private _saleHeader;
    private _dateHeader;
    get template(): InvoiceShortInfoTemplateModel;
    initTemplate(value: InvoiceShortInfoTemplateModel, defaultTemplate: InvoiceComponentTemplateModel): void;
    set saleType(saleType: DocTypeEnum);
    get saleType(): DocTypeEnum;
    get saleHeaderDisplayed(): string;
    set saleHeaderDisplayed(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceShortInfoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InvoiceShortInfoViewService>;
}
