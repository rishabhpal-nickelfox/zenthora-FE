import { InvoiceEmailTemplateViewCommonService } from '../../invoice-email-template-view-common.service';
import { InvoiceComponentTemplateModel, InvoiceFullInfoTemplateModel } from "../../../../../models/sale/template/invoice-template.model";
import { DocTypeEnum } from "../../../../../enums/sale/doc-type.enum";
import * as i0 from "@angular/core";
export declare class InvoiceFullInfoViewService extends InvoiceEmailTemplateViewCommonService {
    private _saleType;
    get termsHeader(): string;
    set termsHeader(value: string);
    get dueDateHeader(): string;
    set dueDateHeader(value: string);
    get dateHeader(): string;
    set dateHeader(value: string);
    get saleHeader(): string;
    set saleHeader(value: string);
    private _saleHeader;
    private _saleHeaderDisplayed;
    private _dateHeader;
    private _dueDateHeader;
    private _termsHeader;
    get template(): InvoiceFullInfoTemplateModel;
    initTemplate(value: InvoiceFullInfoTemplateModel, defaultTemplate: InvoiceComponentTemplateModel): void;
    set saleType(saleType: DocTypeEnum);
    get saleType(): DocTypeEnum;
    get saleHeaderDisplayed(): string;
    set saleHeaderDisplayed(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceFullInfoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InvoiceFullInfoViewService>;
}
