export declare const InvoiceFullInfoLabels: {
    readonly Header: "Header";
};
