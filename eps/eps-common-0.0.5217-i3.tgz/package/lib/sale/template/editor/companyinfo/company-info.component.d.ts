import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { CompanyInfoViewService } from './company-info-view.service';
import { CompanyInfoRowsEnum } from '../../../../enums/sale/company-info-rows.enum';
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CompanyInfoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: CompanyInfoViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    private _template;
    constructor(viewService: CompanyInfoViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    isPresented(column: string): boolean;
    isAnyPresented(columns: string[]): boolean;
    get hideHeader(): boolean;
    get displayedHeader(): string;
    protected readonly CompanyInfoRowsEnum: typeof CompanyInfoRowsEnum;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<CompanyInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompanyInfoComponent, "app-invoice-email-payment-template-company-info", never, {}, {}, never, never, false, never>;
}
