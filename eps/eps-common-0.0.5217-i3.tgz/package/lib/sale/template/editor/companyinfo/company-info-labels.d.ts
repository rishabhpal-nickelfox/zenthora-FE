export declare const CompanyInfoLabels: {
    readonly Header: "Header";
};
