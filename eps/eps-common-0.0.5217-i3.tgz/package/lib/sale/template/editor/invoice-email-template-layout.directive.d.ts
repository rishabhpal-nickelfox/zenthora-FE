import { ComponentFactoryResolver, ComponentRef, OnInit, Type, ViewContainerRef } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from './invoice-email-template-abstract.component';
import * as i0 from "@angular/core";
export declare const INVOICE_TEMPLATE_KEY_COMPONENT_MAP: Map<string, Type<InvoiceEmailTemplateAbstractComponent>>;
export declare class InvoiceEmailTemplateLayoutDirective implements OnInit {
    private container;
    private resolver;
    componentRef: string;
    id: string;
    component: ComponentRef<InvoiceEmailTemplateAbstractComponent>;
    constructor(container: ViewContainerRef, resolver: ComponentFactoryResolver);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceEmailTemplateLayoutDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InvoiceEmailTemplateLayoutDirective, "[appLayoutItem]", never, { "componentRef": { "alias": "componentRef"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}
