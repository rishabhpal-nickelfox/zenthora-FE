import { InvoiceEmailTemplateViewCommonService } from "../invoice-email-template-view-common.service";
import { CustomerNameTemplateModel, InvoiceComponentTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class CustomerNameViewService extends InvoiceEmailTemplateViewCommonService {
    static readonly CUSTOMER_NAME_VALUE: string;
    static readonly CUSTOMER_NAME_DEFAULT_HEADER: string;
    private _defaultTemplate;
    protected _templates: CustomerNameTemplateModel[];
    private _advancedFieldsEnabled;
    initTemplates(templates: CustomerNameTemplateModel[], defaultTemplate: InvoiceComponentTemplateModel): void;
    createTemplate(defaultTemplate: InvoiceComponentTemplateModel): string;
    updateTemplate(customFieldsId: string, fontColor: string, borderColor: string, colorOdd: string, titleColor: string, customerNameHeader: string): void;
    getTemplate(customerNameTemplateId: string): CustomerNameTemplateModel;
    get templates(): CustomerNameTemplateModel[];
    get advancedFieldsEnabled(): boolean;
    set advancedFieldsEnabled(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerNameViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerNameViewService>;
}
