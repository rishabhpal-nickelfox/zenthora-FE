import { ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { SafeStyle } from '@angular/platform-browser';
import { FormControl, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormPageStateService } from "../../../../utils/form-page-state.service";
import { FormPageComponent } from "../../../../pages/form-page.component";
import { ErrorService } from "../../../../utils/errorhandler/error.service";
import { CustomerNameViewService } from "./customer-name-view.service";
import { InvoiceEmailPaymentTemplateComponentsEnum } from "../../../../enums/sale/invoice-email-payment-template-components.enum";
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CustomerNameEditComponent extends FormPageComponent implements OnInit {
    private _viewService;
    private _customerNameId;
    formPageStateService: FormPageStateService;
    protected elementRef: ElementRef;
    errorService: ErrorService;
    private _activeModal;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    protected readonly Labels: {
        readonly Header: "Header";
    };
    readonly MAX_LENGTH: {
        HEADER: number;
    };
    protected styles: SafeStyle;
    protected _customerNameHeader: FormControl<string>;
    protected _borderColor: FormControl<string>;
    protected _fontColor: FormControl<string>;
    protected _colorOdd: FormControl<string>;
    protected _titleColor: FormControl<string>;
    private _form;
    private _template;
    constructor(_viewService: CustomerNameViewService, _customerNameId: string, formPageStateService: FormPageStateService, elementRef: ElementRef, errorService: ErrorService, _activeModal: NgbActiveModal, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    get viewService(): CustomerNameViewService;
    set viewService(value: CustomerNameViewService);
    ngOnInit(): void;
    getForm(): FormGroup;
    get customerNameId(): string;
    protected onReInit(): void;
    close(): void;
    protected onSubmit({ value }: {
        value: any;
    }): void;
    get activeModal(): NgbActiveModal;
    private updateStyles;
    protected readonly CustomerNameViewService: typeof CustomerNameViewService;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnumValue: Map<string, string>;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnum: typeof InvoiceEmailPaymentTemplateComponentsEnum;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerNameEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerNameEditComponent, "app-invoice-email-payment-template-customer-name-edit", never, {}, {}, never, never, false, never>;
}
