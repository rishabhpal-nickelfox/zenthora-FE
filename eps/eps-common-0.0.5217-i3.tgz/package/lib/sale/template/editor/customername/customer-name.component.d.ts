import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { CustomerNameViewService } from "./customer-name-view.service";
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CustomerNameComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: CustomerNameViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    private _template;
    constructor(viewService: CustomerNameViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    get customerNameHeader(): string;
    protected readonly CustomerNameViewService: typeof CustomerNameViewService;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerNameComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerNameComponent, "app-invoice-email-payment-template-customer-name", never, {}, {}, never, never, false, never>;
}
