export declare const CustomerNameLabels: {
    readonly Header: "Header";
};
