import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { LogoViewService } from './logo-view.service';
import { InvoiceEmailPaymentTemplateLogoSizeEnum } from "../../../../enums/sale/invoice-email-payment-template-logo-size.enum";
import * as i0 from "@angular/core";
export declare class LogoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    private viewService;
    private sanitizer;
    protected ch: ChangeDetectorRef;
    private _logo;
    private _logoSize;
    constructor(viewService: LogoViewService, sanitizer: DomSanitizer, ch: ChangeDetectorRef);
    ngOnInit(): void;
    get url(): import("@angular/platform-browser").SafeResourceUrl;
    get logoWidth(): SafeStyle;
    get logoSize(): InvoiceEmailPaymentTemplateLogoSizeEnum;
    set logoSize(value: InvoiceEmailPaymentTemplateLogoSizeEnum);
    get logo(): {
        type: string;
        value: string;
    };
    set logo(value: {
        type: string;
        value: string;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoComponent, "app-invoice-email-payment-template-company-logo", never, {}, {}, never, never, false, never>;
}
