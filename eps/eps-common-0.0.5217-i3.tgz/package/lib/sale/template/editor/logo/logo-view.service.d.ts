import { EventEmitter } from '@angular/core';
import { InvoiceEmailPaymentTemplateLogoSizeEnum } from "../../../../enums/sale/invoice-email-payment-template-logo-size.enum";
import * as i0 from "@angular/core";
export declare class LogoViewService {
    logoChanged: EventEmitter<void>;
    private _logo;
    private _logoSize;
    initTemplate(logo: {
        type: string;
        value: string;
    }, logoSize: InvoiceEmailPaymentTemplateLogoSizeEnum): void;
    get logoSize(): InvoiceEmailPaymentTemplateLogoSizeEnum;
    set logoSize(value: InvoiceEmailPaymentTemplateLogoSizeEnum);
    get logo(): {
        type: string;
        value: string;
    };
    set logo(value: {
        type: string;
        value: string;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LogoViewService>;
}
