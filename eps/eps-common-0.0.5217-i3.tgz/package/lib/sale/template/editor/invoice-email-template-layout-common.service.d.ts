import { GridsterConfig } from 'angular-gridster2';
import { EventEmitter } from '@angular/core';
import { InvoiceEmailTemplateViewCommonService } from './invoice-email-template-view-common.service';
import { GridAreaModel } from "../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare abstract class InvoiceEmailTemplateLayoutCommonService extends InvoiceEmailTemplateViewCommonService {
    layoutChanged: EventEmitter<void>;
    options: GridsterConfig;
    private _layout;
    protected _fontSize: number;
    private _fontSizes;
    protected _lineHeight: number;
    private _lineHeights;
    abstract addItem(layout: any, componentRef: any): any;
    deleteItem(layout: GridAreaModel[], id: any): GridAreaModel[];
    protected checkAndSplice(layout: GridAreaModel[], item: GridAreaModel): GridAreaModel[];
    wasAdded(layout: GridAreaModel[], id: any): boolean;
    set layout(layout: GridAreaModel[]);
    get layout(): GridAreaModel[];
    get fontSize(): number;
    get fontSizes(): number[];
    get lineHeights(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceEmailTemplateLayoutCommonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InvoiceEmailTemplateLayoutCommonService>;
}
