import { ChangeDetectorRef } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare abstract class InvoiceEmailTemplateAbstractComponent {
    protected ch: ChangeDetectorRef;
    constructor(ch: ChangeDetectorRef);
    id: string;
    styles: SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceEmailTemplateAbstractComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InvoiceEmailTemplateAbstractComponent, never, never, {}, {}, never, never, true, never>;
}
