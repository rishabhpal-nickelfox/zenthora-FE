import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { CustomerMemoViewService } from './customer-memo-view.service';
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CustomerMemoComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: CustomerMemoViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    constructor(viewService: CustomerMemoViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerMemoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerMemoComponent, "app-invoice-email-payment-template-customer-memo", never, {}, {}, never, never, false, never>;
}
