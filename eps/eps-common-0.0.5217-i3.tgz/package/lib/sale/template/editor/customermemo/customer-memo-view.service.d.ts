import { InvoiceEmailTemplateViewCommonService } from '../invoice-email-template-view-common.service';
import { EventEmitter } from '@angular/core';
import { CustomerMemoTemplateModel, InvoiceComponentTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import * as i0 from "@angular/core";
export declare class CustomerMemoViewService extends InvoiceEmailTemplateViewCommonService {
    customerMemoChanged: EventEmitter<void>;
    get customerMemo(): string;
    set customerMemo(value: string);
    private _customerMemo;
    get template(): CustomerMemoTemplateModel;
    initTemplate(value: CustomerMemoTemplateModel, defaultTemplate: InvoiceComponentTemplateModel): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerMemoViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerMemoViewService>;
}
