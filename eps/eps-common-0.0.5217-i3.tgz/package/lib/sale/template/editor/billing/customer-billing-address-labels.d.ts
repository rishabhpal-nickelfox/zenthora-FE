export declare const CustomerBillingAddressLabels: {
    readonly Header: "Header";
};
