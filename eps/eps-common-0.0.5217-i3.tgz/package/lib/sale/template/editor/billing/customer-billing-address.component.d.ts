import { OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { InvoiceEmailTemplateAbstractComponent } from '../invoice-email-template-abstract.component';
import { CustomerBillingAddressViewService } from './customer-billing-address-view.service';
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class CustomerBillingAddressComponent extends InvoiceEmailTemplateAbstractComponent implements OnInit {
    protected viewService: CustomerBillingAddressViewService;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    readonly billingAddress = "Sasha Tillou\nFreeman Sporting Goods\n370 Easy St.\nMiddlefield, CA  94482";
    constructor(viewService: CustomerBillingAddressViewService, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    ngOnInit(): void;
    private updateStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerBillingAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerBillingAddressComponent, "app-invoice-email-payment-template-billing-address", never, {}, {}, never, never, false, never>;
}
