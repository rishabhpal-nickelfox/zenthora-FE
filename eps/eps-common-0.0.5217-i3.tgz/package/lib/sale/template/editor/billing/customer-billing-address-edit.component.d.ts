import { ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { SafeStyle } from '@angular/platform-browser';
import { FormControl, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomerBillingAddressViewService } from './customer-billing-address-view.service';
import { FormPageStateService } from "../../../../utils/form-page-state.service";
import { FormPageComponent } from "../../../../pages/form-page.component";
import { ErrorService } from "../../../../utils/errorhandler/error.service";
import { HtmlSanitizerService } from '../../../../utils/html-sanitizer.service';
import { InvoiceEmailPaymentTemplateComponentsEnum } from "../../../../enums/sale/invoice-email-payment-template-components.enum";
import * as i0 from "@angular/core";
export declare class CustomerBillingAddressEditComponent extends FormPageComponent implements OnInit {
    formPageStateService: FormPageStateService;
    protected elementRef: ElementRef;
    errorService: ErrorService;
    private _activeModal;
    protected ch: ChangeDetectorRef;
    private readonly htmlSanitizer;
    readonly billingAddress = "Sasha Tillou\nFreeman Sporting Goods\n370 Easy St.\nMiddlefield, CA  94482";
    protected styles: SafeStyle;
    readonly MAX_LENGTH: {
        HEADER: number;
    };
    readonly Labels: {
        readonly Header: "Header";
    };
    protected _addressHeader: FormControl<string>;
    protected _borderColor: FormControl<string>;
    protected _fontColor: FormControl<string>;
    protected _colorOdd: FormControl<string>;
    protected _titleColor: FormControl<string>;
    private _form;
    constructor(formPageStateService: FormPageStateService, elementRef: ElementRef, errorService: ErrorService, _activeModal: NgbActiveModal, ch: ChangeDetectorRef, htmlSanitizer: HtmlSanitizerService);
    private _viewService;
    get viewService(): CustomerBillingAddressViewService;
    set viewService(value: CustomerBillingAddressViewService);
    ngOnInit(): void;
    getForm(): FormGroup;
    protected onReInit(): void;
    close(): void;
    protected onSubmit({ value }: {
        value: any;
    }): void;
    get activeModal(): NgbActiveModal;
    private updateStyles;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnumValue: Map<string, string>;
    protected readonly InvoiceEmailPaymentTemplateComponentsEnum: typeof InvoiceEmailPaymentTemplateComponentsEnum;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerBillingAddressEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerBillingAddressEditComponent, "app-invoice-email-payment-template-billing-address-edit", never, {}, {}, never, never, false, never>;
}
