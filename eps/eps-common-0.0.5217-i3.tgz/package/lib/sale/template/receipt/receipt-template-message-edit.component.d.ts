import { OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { ComponentWithSubscriptions } from '../../../components/component-with-subscriptions';
import { ReceiptTemplateComponentEnum } from '../../../enums/companymanagement/companysettings/receipt-template-component.enum';
import { ReceiptTemplateModel } from '../../../models/sale/receipt/receipt-template-config.model';
import * as i0 from "@angular/core";
export declare class ReceiptTemplateMessageEditComponent extends ComponentWithSubscriptions implements OnInit {
    protected dialogRef: NbDialogRef<ReceiptTemplateMessageEditComponent>;
    templateConfig: ReceiptTemplateModel;
    excludedPlaceholders: string[];
    readonly ReceiptTemplateComponentEnum: typeof ReceiptTemplateComponentEnum;
    readonly ReceiptTemplateComponentEnumLabel: Record<ReceiptTemplateComponentEnum, string>;
    placeholders: Map<string, string>;
    readonly editorOptions: {
        selectFontSize: boolean;
        selectFontColor: boolean;
        selectBackgroundColor: boolean;
        selectFontStyle: boolean;
        selectListStyle: boolean;
    };
    readonly allowedFontSizes: number[];
    readonly fontSizeMode = "style";
    readonly defaultFontSize = 12;
    readonly defaultColor = "#000000";
    form: FormGroup<{
        message: FormControl<string>;
    }>;
    constructor(dialogRef: NbDialogRef<ReceiptTemplateMessageEditComponent>);
    ngOnInit(): void;
    save(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReceiptTemplateMessageEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReceiptTemplateMessageEditComponent, "app-receipt-template-message-edit", never, { "templateConfig": { "alias": "templateConfig"; "required": false; }; "excludedPlaceholders": { "alias": "excludedPlaceholders"; "required": false; }; }, {}, never, never, false, never>;
}
