import { OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ReceiptTemplateComponentEnum } from '../../../enums/companymanagement/companysettings/receipt-template-component.enum';
import { ReceiptTemplateFieldEnum } from '../../../enums/companymanagement/companysettings/receipt-template-field.enum';
import { ReceiptTemplateModel } from '../../../models/sale/receipt/receipt-template-config.model';
import { ComponentWithSubscriptions } from '../../../components/component-with-subscriptions';
import * as i0 from "@angular/core";
export declare class ReceiptTemplateBlockEditComponent extends ComponentWithSubscriptions implements OnInit {
    activeModal: NgbActiveModal;
    component: ReceiptTemplateComponentEnum;
    templateConfig: ReceiptTemplateModel;
    readonly ReceiptPrintWidthEnumValue: Map<string, string>;
    readonly ReceiptTemplateComponentEnum: typeof ReceiptTemplateComponentEnum;
    readonly ReceiptTemplateComponentEnumLabel: Record<ReceiptTemplateComponentEnum, string>;
    readonly ReceiptTemplateFieldLabel: Record<ReceiptTemplateFieldEnum, string>;
    protected config: ReceiptTemplateModel;
    constructor(activeModal: NgbActiveModal);
    ngOnInit(): void;
    get fields(): ReceiptTemplateFieldEnum[];
    hiddenFields(): ReceiptTemplateFieldEnum[];
    hasField(field: ReceiptTemplateFieldEnum): boolean;
    save(): void;
    addField(field: ReceiptTemplateFieldEnum): void;
    removeField(field: ReceiptTemplateFieldEnum): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReceiptTemplateBlockEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReceiptTemplateBlockEditComponent, "app-receipt-template-block-edit", never, { "component": { "alias": "component"; "required": false; }; "templateConfig": { "alias": "templateConfig"; "required": false; }; }, {}, never, never, false, never>;
}
