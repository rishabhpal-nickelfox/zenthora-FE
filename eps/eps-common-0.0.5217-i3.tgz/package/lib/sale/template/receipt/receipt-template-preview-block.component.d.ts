import { EventEmitter } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { ReceiptTemplateComponentEnum } from '../../../enums/companymanagement/companysettings/receipt-template-component.enum';
import { ReceiptTemplateFieldEnum } from '../../../enums/companymanagement/companysettings/receipt-template-field.enum';
import { ReceiptTemplateModel } from '../../../models/sale/receipt/receipt-template-config.model';
import { ReceiptTemplatePreviewDataService } from './receipt-template-preview-data.service';
import { HtmlSanitizerService } from '../../../utils/html-sanitizer.service';
import * as i0 from "@angular/core";
export declare class ReceiptTemplatePreviewBlockComponent {
    private htmlSanitizer;
    preview: ReceiptTemplatePreviewDataService;
    component: ReceiptTemplateComponentEnum;
    config: ReceiptTemplateModel;
    editable: boolean;
    showLogoPlaceholder: boolean;
    saleTableLabel: string;
    amountLabel: string;
    removeField: EventEmitter<ReceiptTemplateFieldEnum>;
    readonly ReceiptTemplateComponentEnum: typeof ReceiptTemplateComponentEnum;
    readonly ReceiptTemplateFieldEnum: typeof ReceiptTemplateFieldEnum;
    constructor(htmlSanitizer: HtmlSanitizerService, preview: ReceiptTemplatePreviewDataService);
    get safeMessage(): SafeHtml;
    hasField(field: ReceiptTemplateFieldEnum): boolean;
    onRemoveField(field: ReceiptTemplateFieldEnum): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReceiptTemplatePreviewBlockComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReceiptTemplatePreviewBlockComponent, "app-receipt-template-preview-block", never, { "component": { "alias": "component"; "required": false; }; "config": { "alias": "config"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "showLogoPlaceholder": { "alias": "showLogoPlaceholder"; "required": false; }; "saleTableLabel": { "alias": "saleTableLabel"; "required": false; }; "amountLabel": { "alias": "amountLabel"; "required": false; }; }, { "removeField": "removeField"; }, never, never, false, never>;
}
