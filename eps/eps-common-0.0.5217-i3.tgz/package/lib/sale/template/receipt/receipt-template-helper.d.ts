import { ReceiptTemplateModel } from "../../../models/sale/receipt/receipt-template-config.model";
import { ReceiptTemplateComponentEnum } from "../../../enums/companymanagement/companysettings/receipt-template-component.enum";
import { ReceiptTemplateFieldEnum } from "../../../enums/companymanagement/companysettings/receipt-template-field.enum";
export declare class ReceiptTemplateHelper {
    static hasReceiptTemplateComponent(config: ReceiptTemplateModel, component: ReceiptTemplateComponentEnum): boolean;
    static hasReceiptTemplateField(config: ReceiptTemplateModel, field: ReceiptTemplateFieldEnum): boolean;
    static getReceiptTemplateFieldsByComponent(component: ReceiptTemplateComponentEnum): ReceiptTemplateFieldEnum[];
    static hasAnyReceiptTemplateField(config: ReceiptTemplateModel, component: ReceiptTemplateComponentEnum): boolean;
    static addReceiptTemplateComponent(config: ReceiptTemplateModel, component: ReceiptTemplateComponentEnum): void;
    static removeReceiptTemplateComponent(config: ReceiptTemplateModel, component: ReceiptTemplateComponentEnum): void;
    static addReceiptTemplateField(config: ReceiptTemplateModel, field: ReceiptTemplateFieldEnum): void;
    static removeReceiptTemplateField(config: ReceiptTemplateModel, field: ReceiptTemplateFieldEnum): void;
    static replaceReceiptTemplateComponentFields(config: ReceiptTemplateModel, component: ReceiptTemplateComponentEnum, fields: ReceiptTemplateFieldEnum[]): void;
    private static removeReceiptTemplateFields;
}
