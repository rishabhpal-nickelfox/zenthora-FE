import { DomSanitizer, SafeResourceUrl, SafeStyle } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class ReceiptTemplatePreviewDataService {
    private sanitizer;
    private readonly defaultCompany;
    private _company;
    readonly receiptTitle = "Transaction Receipt";
    readonly date = "04/09/2026";
    readonly time = "11:06:57";
    readonly customerName = "Testy T. Test";
    readonly customerEmail = "customer.email@email.com";
    readonly poNumber = "PO-1002";
    readonly memo = "Thank you for your business and have a great day!";
    readonly saleType = "Inv";
    readonly saleNumber = "1002";
    readonly amountPaid = "$3.00";
    readonly tax = "$0.15";
    readonly discount = "$0.00";
    readonly tip = "$1.00";
    readonly shippingAmount = "$2.00";
    readonly paymentMode = "*KEYED*";
    readonly paymentMethod = "VISA";
    readonly paymentLastFour = "1111";
    readonly authorization = "695864206";
    readonly cvv2 = "Match";
    readonly referenceNumber = "60112743236";
    readonly payer = "name";
    constructor(sanitizer: DomSanitizer);
    setCompanyInfo(companyInfo: any): void;
    get company(): {
        logo: {
            type: string;
            value: string;
        };
        name: string;
        street: string;
        city: string;
        state: string;
        zip: string;
        website: string;
        phone: string;
        email: string;
    };
    get companyLogoUrl(): SafeResourceUrl;
    get companyLogoWidth(): SafeStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReceiptTemplatePreviewDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReceiptTemplatePreviewDataService>;
}
