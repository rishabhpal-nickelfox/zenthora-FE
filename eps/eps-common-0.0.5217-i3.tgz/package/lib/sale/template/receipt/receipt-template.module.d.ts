import * as i0 from "@angular/core";
import * as i1 from "./receipt-template-editor.component";
import * as i2 from "./receipt-template-block-edit.component";
import * as i3 from "./receipt-template-preview-block.component";
import * as i4 from "./receipt-template-message-edit.component";
import * as i5 from "@angular/common";
import * as i6 from "@angular/forms";
import * as i7 from "@ng-bootstrap/ng-bootstrap";
import * as i8 from "../../../components/component.module";
import * as i9 from "@nebular/theme";
export declare class ReceiptTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReceiptTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReceiptTemplateModule, [typeof i1.ReceiptTemplateEditorComponent, typeof i2.ReceiptTemplateBlockEditComponent, typeof i3.ReceiptTemplatePreviewBlockComponent, typeof i4.ReceiptTemplateMessageEditComponent], [typeof i5.CommonModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule, typeof i7.NgbModalModule, typeof i8.ComponentModule, typeof i9.NbIconModule, typeof i9.NbDialogModule, typeof i9.NbButtonModule], [typeof i1.ReceiptTemplateEditorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReceiptTemplateModule>;
}
