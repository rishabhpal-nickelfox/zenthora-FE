import * as i0 from "@angular/core";
import * as i1 from "./full/sale-email-payment-full-template-interpret.component";
import * as i2 from "@angular/common";
import * as i3 from "@nebular/theme";
import * as i4 from "../../../components/richtextviewer/rich-text-viewer.component";
import * as i5 from "./common/companyinfo/company-info-template-interpret.component";
export declare class SaleEmailPaymentTemplateInterpretModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SaleEmailPaymentTemplateInterpretModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SaleEmailPaymentTemplateInterpretModule, [typeof i1.SaleEmailPaymentFullTemplateInterpretComponent], [typeof i2.CommonModule, typeof i3.NbIconModule, typeof i3.NbAlertModule, typeof i4.RichTextViewerComponent, typeof i5.CompanyInfoTemplateInterpretComponent], [typeof i1.SaleEmailPaymentFullTemplateInterpretComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SaleEmailPaymentTemplateInterpretModule>;
}
