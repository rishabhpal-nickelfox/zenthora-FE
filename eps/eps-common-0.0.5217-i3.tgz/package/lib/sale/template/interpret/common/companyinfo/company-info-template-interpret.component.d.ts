import { OnInit } from "@angular/core";
import { ComponentWithSubscriptions } from "../../../../../components/component-with-subscriptions";
import { CompanyInfoRowsEnum } from "../../../../../enums/sale/company-info-rows.enum";
import { CompanyInfoTemplateData } from "../../../../../models/sale/template/sale-email-template-data.model";
import * as i0 from "@angular/core";
export declare class CompanyInfoTemplateInterpretComponent extends ComponentWithSubscriptions implements OnInit {
    companyInfoRows: CompanyInfoRowsEnum[];
    companyInfo: CompanyInfoTemplateData;
    protected readonly CompanyInfoRowsEnum: typeof CompanyInfoRowsEnum;
    ngOnInit(): void;
    isCompanyInfoRowPresented(column: string): boolean;
    isAnyCompanyInfoRowPresented(columns: string[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CompanyInfoTemplateInterpretComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompanyInfoTemplateInterpretComponent, "app-company-info-template-interpret", never, { "companyInfoRows": { "alias": "companyInfoRows"; "required": false; }; "companyInfo": { "alias": "companyInfo"; "required": false; }; }, {}, never, never, true, never>;
}
