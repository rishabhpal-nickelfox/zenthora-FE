import { InvoiceEmailPaymentLineStyleEnum } from "../../../../enums/sale/invoice-email-payment-line-style.enum";
import { CompanyInfoRowsEnum } from "../../../../enums/sale/company-info-rows.enum";
import { InvoiceItemsTableTotalsEnum } from "../../../../enums/sale/invoice-items-table-totals.enum";
import { TotalsTemplateModel } from "../../../../models/sale/template/invoice-template.model";
import { SaleEmailTemplateData } from "../../../../models/sale/template/sale-email-template-data.model";
export declare const SALE_TYPE_PLACEHOLDER = "{{SALE_TYPE}}";
export declare const COMPANY_DISPLAY_NAME_PLACEHOLDER = "{{COMPANY_DISPLAY_NAME}}";
export declare class SaleTemplateRenderHelper {
    static getLineCss(color: string, width: number, style: InvoiceEmailPaymentLineStyleEnum): string;
    static replacePlaceholdersInHeader(header: string, displayName: string): string;
    static isPresented(source: CompanyInfoRowsEnum[], column: string): boolean;
    static isAnyPresented(source: CompanyInfoRowsEnum[], columns: string[]): boolean;
    static getHeader(total: InvoiceItemsTableTotalsEnum, totals: TotalsTemplateModel, model: SaleEmailTemplateData): string;
    static getValue(total: InvoiceItemsTableTotalsEnum, model: SaleEmailTemplateData): number;
}
