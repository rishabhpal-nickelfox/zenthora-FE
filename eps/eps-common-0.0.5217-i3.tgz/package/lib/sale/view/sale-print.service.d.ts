import { ElementRef } from "@angular/core";
import * as i0 from "@angular/core";
export declare class SalePrintService {
    print(sale: ElementRef): Promise<void>;
    private fitToPageWidth;
    private neededWidth;
    static ɵfac: i0.ɵɵFactoryDeclaration<SalePrintService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SalePrintService>;
}
