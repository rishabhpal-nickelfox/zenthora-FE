import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class HtmlSanitizerService {
    private readonly domSanitizer;
    private static readonly SANITIZER_CONFIG;
    private readonly purifier;
    constructor(domSanitizer: DomSanitizer);
    sanitizeHtml(rawHtml: string): string;
    sanitizeToSafeHtml(rawHtml: string): SafeHtml;
    trustHtml(rawHtml: string): SafeHtml;
    private createPurifier;
    private containsUnsafeStyleValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<HtmlSanitizerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HtmlSanitizerService>;
}
