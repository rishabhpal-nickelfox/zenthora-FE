import * as i0 from "@angular/core";
export declare class FileService {
    downloadFile(fileName: string, mimetype: string, base64Content: any): void;
    readonly MIME_BY_EXT: Record<string, string>;
    private guessMimeType;
    guessTypeAndDownloadFile(fileName: string, base64Content: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileService>;
}
