import { AbstractControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ServerErrorService {
    private _wsKeyFormControlMap;
    addWsKeyFormControl(key: string, control: AbstractControl): void;
    addWsKeyFormControls(addMap: Map<string, AbstractControl>): void;
    getFormControl(wsKey: string): AbstractControl<any, any>;
    getWsPrefixes(formControl: AbstractControl): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ServerErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServerErrorService>;
}
