import { HttpErrorResponse } from '@angular/common/http';
import { DefaultErrorService } from './default-error.service';
import { AlertService } from "../alert.service";
import { ValidationMessageService } from "../validation-message.service";
import { ServerErrorService } from "../server-error.service";
import * as i0 from "@angular/core";
export declare class ErrorService extends DefaultErrorService {
    alertService: AlertService;
    validationService: ValidationMessageService;
    protected serverErrorService: ServerErrorService;
    constructor(alertService: AlertService, validationService: ValidationMessageService, serverErrorService: ServerErrorService);
    isUserAlreadyExistsError(serverError: HttpErrorResponse): boolean;
    isJWTTokenExpiredError(serverError: HttpErrorResponse): boolean;
    isEntityDisabledError(serverError: HttpErrorResponse): boolean;
    isAccountDisabledError(serverError: HttpErrorResponse): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorService>;
}
