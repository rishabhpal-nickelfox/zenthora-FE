import { HttpErrorResponse } from '@angular/common/http';
import { AlertService } from '../alert.service';
import { ValidationMessageService } from '../validation-message.service';
import { CommonErrorService } from './common-error.service';
import { ServerErrorService } from "../server-error.service";
import * as i0 from "@angular/core";
export declare class DefaultErrorService extends CommonErrorService {
    alertService: AlertService;
    validationService: ValidationMessageService;
    protected serverErrorService?: ServerErrorService;
    constructor(alertService: AlertService, validationService: ValidationMessageService, serverErrorService?: ServerErrorService);
    is500ServerError(serverError: HttpErrorResponse): any;
    is500CustomError(serverError: HttpErrorResponse): any;
    is500CustomNotCheckedError(serverError: HttpErrorResponse): boolean;
    is401NotCheckedError(serverError: HttpErrorResponse): boolean;
    is4xxLogicNotCheckedError(serverError: HttpErrorResponse): boolean;
    is400LogicError(serverError: HttpErrorResponse): boolean;
    is400CustomError(serverError: HttpErrorResponse): any;
    is400FieldValidationError(serverError: HttpErrorResponse): any;
    is400ExistsError(serverError: HttpErrorResponse): any;
    showDefaultError(error: any): void;
    showFieldValidationError(serverError: HttpErrorResponse): void;
    private addServerErrorToField;
    private showAlertIfFieldErrorIsNotVisible;
    private isVisible;
    is404NotFound(serverError: HttpErrorResponse): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultErrorService, [null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultErrorService>;
}
