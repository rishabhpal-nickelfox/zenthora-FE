import { HttpErrorResponse } from '@angular/common/http';
import { AlertService } from '../alert.service';
import { ValidationMessageService } from '../validation-message.service';
import * as i0 from "@angular/core";
export declare class CommonErrorService {
    alertService: AlertService;
    validationService: ValidationMessageService;
    constructor(alertService: AlertService, validationService: ValidationMessageService);
    isConnectionError(serverError: HttpErrorResponse): boolean;
    is401Error(serverError: HttpErrorResponse): boolean;
    showError(header: any, body: any): void;
    showSuccess(header: any, body: any): void;
    throwCheckedErrorResponse(errorResponse: HttpErrorResponse): import("rxjs").Observable<never>;
    isCheckedErrorResponse(error: HttpErrorResponse): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CommonErrorService>;
}
