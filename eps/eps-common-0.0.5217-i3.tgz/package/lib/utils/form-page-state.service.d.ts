import * as i0 from "@angular/core";
export declare class FormPageStateService {
    private _submitClicked;
    submitClicked$: import("rxjs").Observable<boolean>;
    setSubmittedState(state: boolean): void;
    isSubmitted(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormPageStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormPageStateService>;
}
