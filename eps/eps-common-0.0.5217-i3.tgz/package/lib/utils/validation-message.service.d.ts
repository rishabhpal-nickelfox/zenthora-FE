import { FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ValidationMessageService {
    REQUIRED: string;
    MAXLENGTH: (length: any) => string;
    MINLENGTH: (length: any) => string;
    EXACT_LENGTH: (length: any) => string;
    EMAIL: string;
    PHONE: string;
    PATTERN: string;
    DATE: string;
    DIGITS: string;
    IP: string;
    ZIP: string;
    MAXVALUE: (maxvalue: any) => string;
    MAXVALUE_STRICT: (maxvalue: any) => string;
    MINVALUE: (minvalue: any) => string;
    MINVALUE_STRICT: (minvalue: any) => string;
    STARTS_WITH_DIGIT: string;
    CANNOT_BE_EARLIER: (date: any) => string;
    ALREADY_EXISTS: string;
    SELECT_FROM_LIST: string;
    MUST_BE_THE_SAME: (sameValueAs: any) => string;
    getMessage(template: string, parameters: any): any;
    displayFieldCss(form: FormGroup, field: string): {
        'form-control-danger': boolean;
    };
    addServerError(form: FormGroup, fieldCode: string, message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidationMessageService>;
}
