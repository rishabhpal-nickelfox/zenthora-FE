import { ToastrService } from 'ngx-toastr';
import * as i0 from "@angular/core";
export declare class AlertService {
    protected toasterService: ToastrService;
    private readonly _defaultToastrConfig;
    toastrConfig: any;
    constructor(toasterService: ToastrService);
    get defaultToastrConfig(): {
        timeOut: number;
    };
    showError(title: any, body: any): void;
    notImplemented(methodName: any): void;
    showSuccess(title: any, body: any, toastrConfig?: any): void;
    showInfo(title: any, body: any, toastrConfig?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}
