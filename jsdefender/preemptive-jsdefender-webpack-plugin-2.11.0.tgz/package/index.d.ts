import { Compiler } from 'webpack';
/**
 * Describes the available configuration options
 */
export interface ConfigurationOptions {
  booleanLiterals?: boolean | RandomizableOption | null;
  constantArgument?: boolean | null;
  consoleCloaking?: boolean | ConsoleCloackingOptions | null;
  controlFlow?: boolean | ControlFlowOptions | null;
  dateLock?: boolean | DateLockOptions | null;
  debuggerRemoval?: boolean | null;
  devToolsBlocking?: boolean | DevToolsOptions | null;
  domainLock?: boolean | string | DomainLockOptions | null;
  exprSequence?: boolean | null;
  functionReorder?: boolean | RandomizableOption | null;
  globalObjectHiding?: boolean | GlobalHidingOptions | null;
  integerLiterals?: boolean | IntegerLiteralOptions | null;
  localDeclarations?: boolean | LocalDeclarationOptions | null;
  propertyIndirection?: boolean | null;
  propertySparsing?: boolean | null;
  selfDefending?: boolean | number | SelfDefendingOptions | null;
  stringLiterals?: boolean | null;
  variableGrouping?: boolean | null;
}
/**
 * Represents a configuration option that can be randomized.
 */
export interface RandomizableOption {
  randomize?: boolean;
}
/**
 * Represents configuration options for console cloaking
 */
export interface ConsoleCloackingOptions {
  exclude: string | string[];
}
/**
 * Represents configuration options for global object hiding
 */
export interface GlobalHidingOptions {
  usePredefined?: boolean;
  include?: string | string[];
  exclude?: string | string[];
}
/**
 * Represents the configuration options of control flow transform
 */
export interface ControlFlowOptions extends RandomizableOption {
  injectFakeCode?: boolean;
}
/**
 * Represents the configuration options of domain lock transform
 */
export interface DomainLockOptions {
  domainPattern: string;
  errorScript?: string;
}
/**
 * Represents the configuration options of date lock transform
 */
export interface DateLockOptions {
  startDate?: string;
  endDate?: string;
  errorScript?: string;
}
/**
 * Represents the configuration options for DevToos detection
 */
export interface DevToolsOptions {
  patience: number;
}
/**
 * Represents the configuration options of integer literal transform
 */
export interface IntegerLiteralOptions extends RandomizableOption {
  radix?: IntegerLiteralRadix | IntegerLiteralRadix[];
  lower?: number;
  upper?: number;
}
/**
 * Represents the configuration of local declaration transform
 */
export interface LocalDeclarationOptions {
  nameMangling?: NameManglingMode;
  excludeIds?: string | Array<string>;
}
/**
 * Represents self-defending options
 */
export interface SelfDefendingOptions {
  level: number;
  errorScript?: string;
}
declare enum IntegerLiteralRadix {
  /**
   * No radix specified
   */
  None = "none",
  /**
   * All integer literals are converted to binary
   */
  Binary = "binary",
  /**
   * All integer literals are converted to decimal
   */
  Decimal = "decimal",
  /**
   * All integer literals are converted to hexadecimal
   */
  Hexadecimal = "hexadecimal",
  /**
   * All integer literals are converted to octal
   */
  Octal = "octal",
}
declare enum NameManglingMode {
  /**
   * Hexadecimal variable names starting with "_0x" using the sequential
   * index of variable declarations. Suggested to use during testing.
   */
  Sequential = "sequential",
  /**
   * Hexadecimal variable names starting with "_0x" using encoded index of
   * variable declarations. Suggested to use in production.
   */
  Hexadecimal = "hexadecimal",
  /**
   * Convert all variable names to uppercase and lowercase letters plus
   * optional integer suffix
   */
  Base52 = "base52",
  /**
   * Convert all variable names to uppercase and lowercase letters, digits plus
   * optional integer suffix
   */
  Base62 = "base62",
  /**
   * Instead of letters and digit, use emojis when creating a name
   */
  Runic = "runic",
  Glagolitic = "glagolitic",
  Tifinagh = "tifinagh",
}
/**
 * Describes the shape of data that configures the protection process.
 */
export interface ProtectionConfiguration extends ProtectionConfigurationBase {
  /**
   * Global protection settings for each source script
   */
  sourceSets?: (string | SpecialNameSet)[];
  /**
   * Indicates if maps should be generated or not
   */
  generateMaps?: boolean;
  /**
   * Represents JSDefender Runtime file option
   */
  runtimeFile?: string;
}
/**
 * Describes the shape of data is used as a common configuration base class for
 * the protection core and the CLI.
 */
export interface ProtectionConfigurationBase {
  /**
   * Configuration options to use
   */
  settings?: ConfigurationOptions;
  /**
   * The license key to use with the current session
   */
  license?: string;
  /**
   * Licensing requires an email from the user
   */
  email?: string;
  /**
   * License config parameter: should the version update check be run
   * alongside the license validation
   */
  checkForUpdates?: boolean;
  /**
   * You can use named option sets with inline configuration
   */
  namedSets?: {
    [key: string]: ConfigurationOptions;
  };
  /**
   * The target platform to use when protecting the source code.
   */
  esTarget?: EsTarget | null;
  /**
   * The seed value for random number generations.
   */
  randomSeed?: number | null;
  /**
   * Represents JSDefender Runtime protection options
   */
  runtimeInjection?: RuntimeInjectionMode | RuntimeInjectionOptions | null;
  /**
   * Indicates if the protection should ignore unsafe constructs.
   */
  ignoreUnsafeConstructs?: boolean | null;
  /**
   * Indicates if inline protection options should be disabled.
   */
  disableInline?: boolean | null;
  /**
   * Indicates whether source maps should be generated from the source code.
   */
  sourceMaps?: boolean | null;
  /**
   * Enables glob pattern matching for input paths
   */
  glob?: boolean;
  /**
   * Filename -> module ID map for detecting user modules
   */
  filenameMap?: Map<number, string>;
  /**
   *
   */
  protectUserModulesOnly?: boolean;
}
/**
 * The target platform to use when protecting the source code.
 */
export type EsTarget = "es5" | "es2015" | "es2016" | "es2017" | "es2018" | "es2019" | "es2020" | "es2021" | "es2022" | "es2023" | "es2024";
export type SpecialNameSet = "off" | "disableinline" | "disable-inline" | "disableInline" | "default";
declare enum RuntimeInjectionMode {
  /**
   * Puts the JSDefender Runtime into the first non-module file
   */
  FirstNonModule = "firstNonModule",
  /**
   * Puts the JSDefender Runtime into a separate file
   */
  SeparateSource = "separateSource",
  /**
   * Injects a separate Runtime to each source that requires it.
   */
  All = "all",
}
/**
 * Describes the JSDefender Runtime options
 */
export interface RuntimeInjectionOptions {
  mode?: RuntimeInjectionMode;
  options: string;
}
/**
 * Describes the protection configuration options for the configuration file
 */
export interface PluginProtectionConfiguration extends ProtectionConfiguration {
  /**
   * The path to the explicit configuration file. It defaults to `jsdefender.config.json` in the root directory.
   * If none is present then the default configuration is used.
   */
  configurationFile?: string;
  /**
   * The chunk names that should be protected. Everything is protected if omitted.
   *
   * *Note: If the same chunk is specified both in the includeChunks and excludeChunks arrays,
   * then the exclusion takes precedence.*
   */
  includeChunks?: string[];
  /**
   * The chunk names that should not be protected. Everything is protected if omitted.
   *
   * *Note: If the same chunk is specified both in the includeChunks and excludeChunks arrays,
   * then the exclusion takes precedence.*
   */
  excludeChunks?: string[];
  /**
   * The name of the map file.
   */
  mapFile?: string;
  /**
   * The plugin runs in quiet mode and only displays errors and warnings.
   */
  quietMode?: boolean;
  /**
   * The plugin runs also in development mode.
   */
  enableInDevelopmentMode?: boolean;
}
/**
 * This class implements the JSDefender Webpack plugin
 */
export declare class JSDefenderWebpackPlugin {
  constructor(options: PluginProtectionConfiguration);
  /**
   * This method is executed before Webpack is going to emit the compiled assets
   *
   * *Note: The core of this method runs asynchronously*
   */
  apply(compiler: Compiler): void;
}
export {};